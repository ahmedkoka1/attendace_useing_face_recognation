# 📱 Smart Attendance System

A production-ready Flutter attendance management system with Firebase backend, Clean Architecture, BLoC state management, and a professional dark/light UI.

---

## ✨ Features

| Module | Description |
|--------|-------------|
| 🔐 **Auth** | Firebase email/password login, forgot password, admin-only access |
| 📊 **Dashboard** | Real-time stats, attendance %, charts, employee list with search & filter |
| 👥 **Employees** | Add/Edit/Archive/Restore, photo upload, full CRUD |
| ✅ **Attendance** | Manual check-in/out, late detection, working hours calculation |
| 📅 **Calendar** | Per-employee monthly attendance calendar |
| 📄 **Reports** | Daily/Weekly/Monthly reports, PDF & Excel export |
| 🌙 **Themes** | Dark/Light mode toggle, persisted across sessions |

---

## 🏗️ Architecture

```
lib/
├── core/
│   ├── constants/       # AppConstants, AppColors
│   ├── di/              # GetIt dependency injection
│   ├── error/           # Failure class (fpdart Either)
│   ├── router/          # GoRouter navigation
│   └── theme/           # AppTheme (dark/light), ThemeCubit
│
└── modules/
    ├── auth/
    │   ├── domain/repo/         # AuthRepository (abstract + Firebase impl)
    │   └── presentation/
    │       ├── cubit/           # AuthCubit + AuthState
    │       ├── screens/         # LoginScreen
    │       └── widgets/         # ForgotPasswordDialog
    ├── dashboard/
    │   ├── domain/
    │   │   ├── models/          # DashboardStatsModel, AdminModel
    │   │   └── repo/            # DashboardRepository
    │   └── presentation/
    │       ├── cubit/           # DashboardCubit + real-time stream
    │       ├── screens/         # DashboardScreen
    │       └── widgets/         # StatCard, AttendanceChart
    ├── employees/
    │   ├── domain/
    │   │   ├── models/          # EmployeeModel
    │   │   └── repo/            # EmployeeRepository (Firebase + Storage)
    │   └── presentation/
    │       ├── cubit/           # EmployeeCubit (paginated)
    │       ├── screens/         # EmployeeListScreen, EmployeeDetailScreen, AddEmployeeScreen
    │       └── widgets/         # EmployeeCard
    ├── attendance/
    │   ├── domain/
    │   │   ├── models/          # AttendanceModel
    │   │   └── repo/            # AttendanceRepository
    │   └── presentation/
    │       ├── cubit/           # AttendanceCubit
    │       └── screens/         # AttendanceScreen
    └── reports/
        └── presentation/        # ReportsScreen (PDF + Excel)
```

---

## 🚀 Setup & Installation

### Prerequisites
- Flutter 3.19+ (`flutter --version`)
- Android Studio / VS Code
- Firebase account (free)

---

### Step 1 — Clone & Install

```bash
cd smart_attendance
flutter pub get
```

---

### Step 2 — Firebase Setup

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click **Add project** → name it `smart-attendance`
3. Enable these services:
   - **Authentication** → Sign-in method → Email/Password → Enable
   - **Cloud Firestore** → Create database → Start in **production mode**
   - **Firebase Storage** → Get started

#### Install FlutterFire CLI
```bash
dart pub global activate flutterfire_cli
```

#### Configure Firebase for Flutter
```bash
flutterfire configure
```
Select your project and platforms (Android + iOS). This auto-generates `lib/firebase_options.dart`.

#### Add `google-services.json` (Android)
- Firebase Console → Project Settings → Your apps → Android
- Download `google-services.json`
- Place it at: `android/app/google-services.json`

---

### Step 3 — Create Admin Account

```bash
cd smart_attendance
node setup_admin.js
```

> Edit `setup_admin.js` first to set your email, password and company name.
> You need `serviceAccountKey.json` from Firebase Console → Project Settings → Service Accounts.

---

### Step 4 — Apply Firestore Security Rules

In Firebase Console → Firestore → Rules, paste the contents of `firestore.rules`.

In Firebase Console → Storage → Rules, paste the contents of `storage.rules`.

---

### Step 5 — Run the App

```bash
# Debug mode
flutter run

# Release APK
flutter build apk --release

# Release App Bundle (for Play Store)
flutter build appbundle --release
```

The APK will be at:
```
build/app/outputs/flutter-apk/app-release.apk
```

---

## 🗄️ Firestore Database Design

### `users` collection
```json
{
  "name": "System Admin",
  "email": "admin@company.com",
  "companyName": "My Company",
  "role": "admin",
  "photoUrl": null,
  "createdAt": "Timestamp"
}
```

### `employees` collection
```json
{
  "name": "John Doe",
  "email": "john@company.com",
  "phone": "+1234567890",
  "position": "Software Engineer",
  "department": "Engineering",
  "photoUrl": "https://...",
  "address": "123 Main St",
  "salary": 5000,
  "joiningDate": "Timestamp",
  "status": "active",
  "createdAt": "Timestamp",
  "updatedAt": "Timestamp"
}
```

### `attendance` collection
```json
{
  "employeeId": "abc123",
  "employeeName": "John Doe",
  "employeePhotoUrl": "https://...",
  "department": "Engineering",
  "date": "Timestamp",
  "dateKey": "2024-01-15",
  "checkIn": "Timestamp",
  "checkOut": "Timestamp",
  "status": "present|absent|late|earlyLeave|leave",
  "workingHours": 8.5,
  "deviceUsed": "mobile",
  "isDuplicate": false
}
```

---

## 🔒 Security Notes

- Only users with `role: "admin"` in Firestore can log in to this app
- Firestore rules enforce read/write access per role
- Storage rules limit uploads to images < 5MB
- Passwords are handled entirely by Firebase Auth (never stored in Firestore)

---

## 🏗️ Building the APK

```bash
# Make sure you've completed Firebase setup first
flutter build apk --release --no-shrink
```

> If you see Firebase init errors, double-check that `google-services.json` is in `android/app/`

---

## 🧩 Technology Stack

| Layer | Technology |
|-------|-----------|
| UI | Flutter + Material 3 |
| State | flutter_bloc (BLoC/Cubit) |
| Navigation | GoRouter |
| DI | GetIt |
| Backend | Firebase (Auth + Firestore + Storage + FCM) |
| Charts | fl_chart |
| PDF | pdf + printing |
| Excel | excel package |
| Error Handling | fpdart (Either) |
| Animations | flutter_animate |

---

## 📞 Support

If you encounter issues, check:
1. `google-services.json` is in place
2. `flutterfire configure` was run
3. Firebase Auth Email/Password is enabled
4. The admin account was created via `setup_admin.js`
