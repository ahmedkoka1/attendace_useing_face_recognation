// ============================================================
// Admin Setup Script (Node.js)
// Run this ONCE to create your first admin account in Firestore
//
// Steps:
//   1. npm install firebase-admin
//   2. Download your Firebase Service Account key from:
//      Firebase Console → Project Settings → Service accounts
//      → Generate new private key → save as serviceAccountKey.json
//   3. node setup_admin.js
// ============================================================

const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const auth = admin.auth();
const db = admin.firestore();

async function createAdmin() {
  const email = 'admin@smartattendance.com'; // ← Change this
  const password = 'Admin@123456';            // ← Change this
  const companyName = 'My Company';           // ← Change this
  const adminName = 'System Admin';           // ← Change this

  try {
    // Create Firebase Auth user
    const userRecord = await auth.createUser({
      email,
      password,
      displayName: adminName,
      emailVerified: true,
    });

    console.log('✅ Auth user created:', userRecord.uid);

    // Create Firestore document with admin role
    await db.collection('users').doc(userRecord.uid).set({
      name: adminName,
      email,
      companyName,
      role: 'admin',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log('✅ Admin document created in Firestore');
    console.log('');
    console.log('🎉 Admin setup complete!');
    console.log('   Email:', email);
    console.log('   Password:', password);
    console.log('   UID:', userRecord.uid);
    console.log('');
    console.log('⚠️  Change password after first login!');

  } catch (err) {
    if (err.code === 'auth/email-already-exists') {
      console.log('ℹ️  User already exists. Updating Firestore document...');
      const user = await auth.getUserByEmail(email);
      await db.collection('users').doc(user.uid).set({
        name: adminName,
        email,
        companyName,
        role: 'admin',
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
      console.log('✅ Admin document updated.');
    } else {
      console.error('❌ Error:', err.message);
    }
  }

  process.exit(0);
}

createAdmin();
