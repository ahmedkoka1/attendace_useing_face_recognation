import 'dart:io';

import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/network/api_exceptions.dart';
import 'package:smart_attendance/modules/employees/data/datasources/employee_remote_data_source.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

class EmployeeRepositoryImpl implements EmployeeRepository {
  final EmployeeRemoteDataSource _remote;
  EmployeeRepositoryImpl(this._remote);

  @override
  Future<Either<Failure, List<EmployeeModel>>> getEmployees({
    String? department, String? search, EmployeeStatus? status,
  }) async {
    try {
      // The backend's GET /api/employees doesn't document query params for
      // department/search/status filtering, so filtering is done
      // client-side here (same effective behavior as before, just on real
      // data instead of the fake in-memory list).
      var list = await _remote.getEmployees();
      if (status != null) list = list.where((e) => e.status == status).toList();
      if (department != null && department.isNotEmpty) {
        list = list.where((e) => e.department == department).toList();
      }
      if (search != null && search.isNotEmpty) {
        final q = search.toLowerCase();
        list = list.where((e) =>
          e.name.toLowerCase().contains(q) ||
          e.email.toLowerCase().contains(q) ||
          e.position.toLowerCase().contains(q)
        ).toList();
      }
      return Right(list);
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<Either<Failure, EmployeeModel>> getEmployee(String id) async {
    try {
      return Right(await _remote.getEmployee(id));
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<Either<Failure, EmployeeModel>> addEmployee(Map<String, dynamic> data) async {
    try {
      // Only the seven fields the backend's CreateEmployeeRequest accepts
      // are read here: name, email, phoneNumber, dateOfBirth, salary,
      // department, jobTitle.
      final employee = EmployeeModel(
        id: '',
        name: data['name'] ?? '',
        email: data['email'] ?? '',
        phone: data['phoneNumber'] ?? '',
        position: data['jobTitle'] ?? '',
        department: data['department'] ?? '',
        salary: data['salary'],
        joiningDate: DateTime.now(),
        dateOfBirth: data['dateOfBirth'],
        createdAt: DateTime.now(),
      );
      return Right(await _remote.createEmployee(employee));
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<Either<Failure, EmployeeModel>> updateEmployee(String id, Map<String, dynamic> data) async {
    try {
      final existing = await _remote.getEmployee(id);
      // Only the seven fields the backend's UpdateEmployeeRequest accepts
      // are applied here; anything else (address, joiningDate, etc.) is
      // left untouched on the existing employee.
      final updated = existing.copyWith(
        name: data['name'], email: data['email'], phone: data['phoneNumber'],
        position: data['jobTitle'], department: data['department'],
        salary: data['salary'],
        dateOfBirth: data['dateOfBirth'],
        status: data['isActive'] == false ? EmployeeStatus.archived : null,
        updatedAt: DateTime.now(),
      );
      return Right(await _remote.updateEmployee(id, updated));
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<Either<Failure, void>> deleteEmployee(String id) async {
    try {
      await _remote.deleteEmployee(id);
      return const Right(null);
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<Either<Failure, void>> archiveEmployee(String id) async {
    // Soft-delete: PUT the employee back with isActive=false, using the
    // real DELETE endpoint only for the permanent "remove" action. Mirrors
    // the soft-delete-vs-hard-delete distinction already built into the UI
    // (employee_list_screen's "archive" vs "remove" actions).
    try {
      final existing = await _remote.getEmployee(id);
      await _remote.updateEmployee(id, existing.copyWith(status: EmployeeStatus.archived));
      return const Right(null);
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<Either<Failure, String>> uploadEmployeePhoto(String id, File imageFile) async {
    try {
      final url = await _remote.uploadEmployeePhoto(id, imageFile);
      return Right(url);
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }
}
