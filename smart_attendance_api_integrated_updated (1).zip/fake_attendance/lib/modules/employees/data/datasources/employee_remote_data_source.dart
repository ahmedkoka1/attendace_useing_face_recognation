import 'dart:io';

import 'package:dio/dio.dart';
import 'package:smart_attendance/core/constants/api_constants.dart';
import 'package:smart_attendance/core/network/api_client.dart';
import 'package:smart_attendance/core/network/api_exceptions.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';

/// Talks to the backend's `/api/employees` REST endpoints. Mirrors the
/// pattern already used by [AttendanceRemoteDataSource] - this is the only
/// class that knows about the wire format for employees.
abstract class EmployeeRemoteDataSource {
  Future<List<EmployeeModel>> getEmployees();
  Future<EmployeeModel> getEmployee(String id);
  Future<EmployeeModel> createEmployee(EmployeeModel employee);
  Future<EmployeeModel> updateEmployee(String id, EmployeeModel employee);
  Future<void> deleteEmployee(String id);

  /// Uploads [imageFile] as `multipart/form-data` to replace the employee's
  /// profile photo. Returns the photo URL the backend reports back (falls
  /// back to an empty string if the response doesn't include one).
  Future<String> uploadEmployeePhoto(String employeeId, File imageFile);
}

class EmployeeRemoteDataSourceImpl implements EmployeeRemoteDataSource {
  final ApiClient _apiClient;
  EmployeeRemoteDataSourceImpl(this._apiClient);

  @override
  Future<List<EmployeeModel>> getEmployees() async {
    try {
      final response = await _apiClient.dio.get(ApiConstants.employeesEndpoint);
      final data = response.data;
      final list = (data is Map && data['data'] is List)
          ? data['data'] as List
          : (data is List ? data : const []);
      return list
          .whereType<Map>()
          .map((e) => EmployeeModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }

  @override
  Future<EmployeeModel> getEmployee(String id) async {
    try {
      final response = await _apiClient.dio.get(ApiConstants.employeeByIdEndpoint(id));
      final data = response.data;
      final map = (data is Map && data['data'] is Map) ? data['data'] as Map : data as Map;
      return EmployeeModel.fromJson(Map<String, dynamic>.from(map));
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }

  @override
  Future<EmployeeModel> createEmployee(EmployeeModel employee) async {
    try {
      final response = await _apiClient.dio.post(
        ApiConstants.employeesEndpoint,
        data: employee.toRequestJson(),
      );
      final data = response.data;
      if (data is Map) {
        final map = (data['data'] is Map) ? data['data'] as Map : data;
        final created = EmployeeModel.fromJson(Map<String, dynamic>.from(map));
        // Fall back to what we sent if the response omits fields (e.g. a
        // bare `{ "id": ... }` acknowledgement).
        if (created.name.isNotEmpty) return created;
      }
      return employee;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }

  @override
  Future<EmployeeModel> updateEmployee(String id, EmployeeModel employee) async {
    try {
      final response = await _apiClient.dio.put(
        ApiConstants.employeeByIdEndpoint(id),
        data: {
          ...employee.toRequestJson(),
          'isActive': employee.isActive,
        },
      );
      final data = response.data;
      if (data is Map && data.isNotEmpty) {
        final map = (data['data'] is Map) ? data['data'] as Map : data;
        final updated = EmployeeModel.fromJson(Map<String, dynamic>.from(map));
        if (updated.name.isNotEmpty) return updated;
      }
      return employee;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }

  @override
  Future<void> deleteEmployee(String id) async {
    try {
      await _apiClient.dio.delete(ApiConstants.employeeByIdEndpoint(id));
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }

  @override
  Future<String> uploadEmployeePhoto(String employeeId, File imageFile) async {
    try {
      final formData = FormData.fromMap({
        ApiConstants.fieldPhoto: await MultipartFile.fromFile(
          imageFile.path,
          filename: imageFile.path.split(Platform.pathSeparator).last,
        ),
      });
      final response = await _apiClient.dio.post(
        ApiConstants.employeePhotoUploadEndpoint(employeeId),
        data: formData,
      );
      final data = response.data;
      if (data is Map) {
        final map = (data['data'] is Map) ? data['data'] as Map : data;
        final url = (map['photoUrl'] ?? map['url'] ?? map['photo']);
        if (url != null) return url.toString();
      }
      return '';
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }
}
