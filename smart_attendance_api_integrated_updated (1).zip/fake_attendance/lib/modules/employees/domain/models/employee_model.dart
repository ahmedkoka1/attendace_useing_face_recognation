enum EmployeeStatus { active, archived }

class EmployeeModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String position;
  final String department;
  final String? photoUrl;
  final String? address;
  final double? salary;
  final DateTime joiningDate;

  /// Required by the backend's CreateEmployeeRequest/UpdateEmployeeRequest
  /// (`dateOfBirth`), which has no client-side equivalent that pre-existed
  /// in this model. Added here rather than dropped, since the API rejects
  /// employee creation without it.
  final DateTime? dateOfBirth;
  final EmployeeStatus status;
  final DateTime createdAt;
  final DateTime? updatedAt;

  const EmployeeModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.position,
    required this.department,
    this.photoUrl,
    this.address,
    this.salary,
    required this.joiningDate,
    this.dateOfBirth,
    this.status = EmployeeStatus.active,
    required this.createdAt,
    this.updatedAt,
  });

  EmployeeModel copyWith({
    String? id, String? name, String? email, String? phone,
    String? position, String? department, String? photoUrl,
    String? address, double? salary, DateTime? joiningDate,
    DateTime? dateOfBirth,
    EmployeeStatus? status, DateTime? createdAt, DateTime? updatedAt,
  }) {
    return EmployeeModel(
      id: id ?? this.id, name: name ?? this.name, email: email ?? this.email,
      phone: phone ?? this.phone, position: position ?? this.position,
      department: department ?? this.department, photoUrl: photoUrl ?? this.photoUrl,
      address: address ?? this.address, salary: salary ?? this.salary,
      joiningDate: joiningDate ?? this.joiningDate,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt, updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// Builds a model from the backend's JSON representation. The exact
  /// response shape (`EmployeeResponse`) wasn't visible in the Swagger
  /// screenshots provided (only request DTOs were captured), so this reads
  /// defensively and falls back to sane defaults for anything missing/named
  /// differently than expected - verify field names once the live Swagger
  /// JSON is reachable.
  factory EmployeeModel.fromJson(Map<String, dynamic> json) {
    DateTime? parseDate(dynamic v) {
      if (v == null) return null;
      return DateTime.tryParse(v.toString());
    }

    return EmployeeModel(
      id: (json['id'] ?? json['employeeId'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      email: (json['email'] ?? '').toString(),
      phone: (json['phoneNumber'] ?? json['phone'] ?? '').toString(),
      position: (json['jobTitle'] ?? json['position'] ?? '').toString(),
      department: (json['department'] ?? '').toString(),
      photoUrl: json['photoUrl']?.toString(),
      address: json['address']?.toString(),
      salary: (json['salary'] as num?)?.toDouble(),
      joiningDate: parseDate(json['joiningDate']) ?? parseDate(json['createdAt']) ?? DateTime.now(),
      dateOfBirth: parseDate(json['dateOfBirth']),
      status: (json['isActive'] == false)
          ? EmployeeStatus.archived
          : EmployeeStatus.active,
      createdAt: parseDate(json['createdAt']) ?? DateTime.now(),
      updatedAt: parseDate(json['updatedAt']),
    );
  }

  /// Maps this model onto the backend's Create/UpdateEmployeeRequest body
  /// exactly - these are the only seven fields the API accepts, using the
  /// exact property names it expects (`phoneNumber` instead of `phone`,
  /// `jobTitle` instead of `position`), with `dateOfBirth` formatted as
  /// `yyyy-MM-dd` (date only, no time component).
  Map<String, dynamic> toRequestJson() {
    final dob = dateOfBirth ?? DateTime(2000, 1, 1);
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final formattedDob =
        '${dob.year.toString().padLeft(4, '0')}-${twoDigits(dob.month)}-${twoDigits(dob.day)}';

    return {
      'name': name,
      'email': email,
      'phoneNumber': phone,
      'dateOfBirth': formattedDob,
      'salary': salary ?? 0,
      'department': department,
      'jobTitle': position,
    };
  }

  bool get isActive => status == EmployeeStatus.active;
  bool get isArchived => status == EmployeeStatus.archived;

  String get initials {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }
}
