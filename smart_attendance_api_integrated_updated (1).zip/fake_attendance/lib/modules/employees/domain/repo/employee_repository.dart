import 'dart:io';

import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';

abstract class EmployeeRepository {
  Future<Either<Failure, List<EmployeeModel>>> getEmployees({String? department, String? search, EmployeeStatus? status});
  Future<Either<Failure, EmployeeModel>> getEmployee(String id);
  Future<Either<Failure, EmployeeModel>> addEmployee(Map<String, dynamic> data);
  Future<Either<Failure, EmployeeModel>> updateEmployee(String id, Map<String, dynamic> data);
  Future<Either<Failure, void>> deleteEmployee(String id);
  Future<Either<Failure, void>> archiveEmployee(String id);

  /// Uploads a new profile photo for [id] and returns the resulting photo
  /// URL on success.
  Future<Either<Failure, String>> uploadEmployeePhoto(String id, File imageFile);
}
