import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

abstract class EmployeeState extends Equatable {
  @override List<Object?> get props => [];
}
class EmployeeInitialState extends EmployeeState {}
class EmployeeLoadingState extends EmployeeState {}
class EmployeePaginatingState extends EmployeeState {
  final List<EmployeeModel> employees;
  EmployeePaginatingState(this.employees);
  @override List<Object?> get props => [employees.length];
}
class EmployeeLoadedState extends EmployeeState {
  final List<EmployeeModel> employees;
  final bool hasMore;
  EmployeeLoadedState({required this.employees, this.hasMore = false});
  @override List<Object?> get props => [employees.length, hasMore];
}
class EmployeeErrorState extends EmployeeState {
  final Failure failure;
  EmployeeErrorState(this.failure);
  @override List<Object?> get props => [failure.message];
}
class EmployeeActionLoadingState extends EmployeeState {}
class EmployeeActionSuccessState extends EmployeeState {
  final String message;
  EmployeeActionSuccessState(this.message);
}
class EmployeeActionErrorState extends EmployeeState {
  final Failure failure;
  EmployeeActionErrorState(this.failure);
}

class EmployeeCubit extends Cubit<EmployeeState> {
  final EmployeeRepository _repo;
  final ScrollController scrollController = ScrollController();
  List<EmployeeModel> _employees = [];
  String _search = '';
  String _department = '';

  EmployeeCubit(this._repo) : super(EmployeeInitialState());

  Future<void> loadEmployees({bool reset = true}) async {
    if (reset) { _employees = []; emit(EmployeeLoadingState()); }
    final result = await _repo.getEmployees(search: _search, department: _department);
    result.fold(
      (f) => emit(EmployeeErrorState(f)),
      (list) {
        _employees = list;
        emit(EmployeeLoadedState(employees: _employees, hasMore: false));
      },
    );
  }

  Future<void> loadMore() async {}

  void setSearch(String q) { _search = q; loadEmployees(); }
  void setDepartment(String dept) { _department = dept; loadEmployees(); }

  Future<void> deleteEmployee(String id) async {
    emit(EmployeeActionLoadingState());
    final result = await _repo.archiveEmployee(id);
    result.fold(
      (f) => emit(EmployeeActionErrorState(f)),
      (_) {
        _employees.removeWhere((e) => e.id == id);
        emit(EmployeeActionSuccessState('Employee archived successfully'));
        emit(EmployeeLoadedState(employees: _employees, hasMore: false));
      },
    );
  }

  Future<void> removeEmployee(String id) async {
    emit(EmployeeActionLoadingState());
    final result = await _repo.deleteEmployee(id);
    result.fold(
      (f) => emit(EmployeeActionErrorState(f)),
      (_) {
        _employees.removeWhere((e) => e.id == id);
        emit(EmployeeActionSuccessState('Employee removed successfully'));
        emit(EmployeeLoadedState(employees: _employees, hasMore: false));
      },
    );
  }

  @override
  Future<void> close() {
    scrollController.dispose();
    return super.close();
  }
}
