import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:smart_attendance/core/constants/app_constants.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/add_employee_screen.dart';

class EmployeeDetailScreen extends StatefulWidget {
  final String employeeId;

  const EmployeeDetailScreen({super.key, required this.employeeId});

  @override
  State<EmployeeDetailScreen> createState() => _EmployeeDetailScreenState();
}

class _EmployeeDetailScreenState extends State<EmployeeDetailScreen> {
  EmployeeModel? _employee;
  List<AttendanceModel> _attendance = [];
  bool _loading = true;
  String? _error;

  int _presentDays = 0;
  int _absentDays = 0;
  int _lateDays = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);

    final empResult = await getIt<EmployeeRepository>().getEmployee(widget.employeeId);
    empResult.fold(
      (f) => setState(() { _error = f.message; _loading = false; }),
      (emp) async {
        final attResult = await getIt<AttendanceRepository>().getAttendanceByEmployee(widget.employeeId);

        attResult.fold(
          (f) => setState(() { _error = f.message; _loading = false; }),
          (att) {
            _presentDays = att.where((a) =>
                a.status == AttendanceStatus.present ||
                a.status == AttendanceStatus.late).length;
            _absentDays = att.where((a) => a.status == AttendanceStatus.absent).length;
            _lateDays = att.where((a) => a.status == AttendanceStatus.late).length;
            setState(() {
              _employee = emp;
              _attendance = att;
              _loading = false;
            });
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    if (_loading) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    if (_error != null) return Scaffold(appBar: AppBar(), body: Center(child: Text(_error!)));

    final emp = _employee!;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Header
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () async {
                  final updated = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(
                        builder: (_) => AddEmployeeScreen(employee: emp)),
                  );
                  if (updated == true && mounted) _loadData();
                },
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                onPressed: () => _confirmDelete(context, emp),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [cs.primary, cs.secondary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      CircleAvatar(
                        radius: 48,
                        backgroundColor: Colors.white.withValues(alpha: 0.2),
                        backgroundImage: emp.photoUrl != null
                            ? null : null,
                        child: emp.photoUrl == null
                            ? Text(emp.initials,
                                style: const TextStyle(
                                    fontSize: 28, fontWeight: FontWeight.w700,
                                    color: Colors.white))
                            : null,
                      ),
                      const SizedBox(height: 12),
                      Text(emp.name,
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w700,
                              color: Colors.white)),
                      Text(emp.position,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 14)),
                    ],
                  ),
                ),
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Stats
                Row(children: [
                  _StatChip(label: 'Present', value: _presentDays,
                      color: const Color(AppColors.presentColor)),
                  const SizedBox(width: 10),
                  _StatChip(label: 'Absent', value: _absentDays,
                      color: const Color(AppColors.absentColor)),
                  const SizedBox(width: 10),
                  _StatChip(label: 'Late', value: _lateDays,
                      color: const Color(AppColors.lateColor)),
                ]),
                const SizedBox(height: 20),

                // Info Card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(children: [
                      _InfoRow(Icons.email_outlined, 'Email', emp.email),
                      _InfoRow(Icons.phone_outlined, 'Phone', emp.phone),
                      _InfoRow(Icons.business_outlined, 'Department', emp.department),
                      _InfoRow(Icons.calendar_today, 'Joining Date',
                          DateFormat('MMM dd, yyyy').format(emp.joiningDate)),
                      if (emp.address != null)
                        _InfoRow(Icons.location_on_outlined, 'Address', emp.address!),
                      if (emp.salary != null)
                        _InfoRow(Icons.attach_money, 'Salary',
                            '\$${NumberFormat('#,###').format(emp.salary)}'),
                    ]),
                  ),
                ),
                const SizedBox(height: 20),

                // Calendar
                Text('Attendance Calendar',
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: TableCalendar(
                      firstDay: DateTime(DateTime.now().year, DateTime.now().month - 2, 1),
                      lastDay: DateTime.now(),
                      focusedDay: DateTime.now(),
                      calendarFormat: CalendarFormat.month,
                      headerStyle: HeaderStyle(
                        formatButtonVisible: false,
                        titleCentered: true,
                        titleTextStyle: theme.textTheme.titleSmall!
                            .copyWith(fontWeight: FontWeight.w600),
                      ),
                      calendarBuilders: CalendarBuilders(
                        defaultBuilder: (ctx, day, focused) {
                          final att = _attendance.where((a) =>
                              a.date.year == day.year &&
                              a.date.month == day.month &&
                              a.date.day == day.day).firstOrNull;

                          if (att == null) return null;

                          Color color;
                          switch (att.status) {
                            case AttendanceStatus.present:
                              color = const Color(AppColors.presentColor);
                              break;
                            case AttendanceStatus.absent:
                              color = const Color(AppColors.absentColor);
                              break;
                            case AttendanceStatus.late:
                              color = const Color(AppColors.lateColor);
                              break;
                            default:
                              color = const Color(AppColors.leaveColor);
                          }

                          return Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: color.withValues(alpha: 0.2),
                              shape: BoxShape.circle,
                              border: Border.all(color: color, width: 1.5),
                            ),
                            child: Center(
                              child: Text('${day.day}',
                                  style: TextStyle(
                                      color: color, fontWeight: FontWeight.w600,
                                      fontSize: 13)),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 80),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, EmployeeModel emp) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete Employee'),
        content: Text(
            'Are you sure you want to permanently delete ${emp.name}? '
            'This action cannot be undone and all their data, including attendance records, will be lost.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              final result =
                  await getIt<EmployeeRepository>().deleteEmployee(emp.id);
              if (!mounted) return;
              result.fold(
                (f) => ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text(f.message),
                      backgroundColor: Colors.red),
                ),
                (_) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${emp.name} deleted successfully')),
                  );
                  Navigator.pop(context, true);
                },
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final int value;
  final Color color;

  const _StatChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(
            children: [
              Text(value.toString(),
                  style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w700, color: color)),
              const SizedBox(height: 4),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 18, color: theme.colorScheme.primary),
          const SizedBox(width: 12),
          Text('$label: ', style: theme.textTheme.bodySmall),
          Expanded(
            child: Text(value,
                style: theme.textTheme.bodyMedium
                    ?.copyWith(fontWeight: FontWeight.w500),
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }
}
