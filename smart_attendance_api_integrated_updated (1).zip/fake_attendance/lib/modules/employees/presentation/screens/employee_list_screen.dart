import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';
import 'package:smart_attendance/modules/employees/presentation/cubit/employee_cubit.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/add_employee_screen.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/employee_detail_screen.dart';
import 'package:smart_attendance/modules/employees/presentation/widgets/employee_card.dart';

class EmployeeListScreen extends StatelessWidget {
  const EmployeeListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => EmployeeCubit(getIt<EmployeeRepository>())..loadEmployees(),
      child: const _EmployeeListView(),
    );
  }
}

class _EmployeeListView extends StatefulWidget {
  const _EmployeeListView();

  @override
  State<_EmployeeListView> createState() => _EmployeeListViewState();
}

class _EmployeeListViewState extends State<_EmployeeListView> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return BlocListener<EmployeeCubit, EmployeeState>(
      listener: (context, state) {
        if (state is EmployeeActionSuccessState) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: const Color(0xFF4CAF50),
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
        if (state is EmployeeActionErrorState) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.failure.message),
              backgroundColor: cs.error,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Employees'),
          actions: [
            IconButton(
              icon: const Icon(Icons.person_add_outlined),
              onPressed: () async {
                final added = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(builder: (_) => const AddEmployeeScreen()),
                );
                if (added == true && context.mounted) {
                  context.read<EmployeeCubit>().loadEmployees();
                }
              },
            ),
          ],
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  hintText: 'Search by name, email, position...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searchCtrl.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () {
                            _searchCtrl.clear();
                            context.read<EmployeeCubit>().setSearch('');
                          },
                        )
                      : null,
                ),
                onChanged: (q) => context.read<EmployeeCubit>().setSearch(q),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: BlocBuilder<EmployeeCubit, EmployeeState>(
                builder: (context, state) {
                  if (state is EmployeeLoadingState) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (state is EmployeeErrorState) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.error_outline, size: 56, color: cs.error),
                          const SizedBox(height: 12),
                          Text(state.failure.message),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: () =>
                                context.read<EmployeeCubit>().loadEmployees(),
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    );
                  }

                  final employees = state is EmployeeLoadedState
                      ? state.employees
                      : state is EmployeePaginatingState
                          ? state.employees
                          : <EmployeeModel>[];

                  if (employees.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.people_outline, size: 80,
                              color: cs.onSurface.withValues(alpha: 0.2)),
                          const SizedBox(height: 16),
                          Text('No employees found',
                              style: theme.textTheme.titleMedium),
                        ],
                      ),
                    );
                  }

                  return RefreshIndicator(
                    onRefresh: () =>
                        context.read<EmployeeCubit>().loadEmployees(),
                    child: ListView.separated(
                      controller: context.read<EmployeeCubit>().scrollController,
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                      itemCount: employees.length +
                          (state is EmployeePaginatingState ? 1 : 0),
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        if (i == employees.length) {
                          return const Center(
                              child: Padding(
                            padding: EdgeInsets.all(16),
                            child: CircularProgressIndicator(),
                          ));
                        }
                        return EmployeeCard(
                          employee: employees[i],
                          onTap: () async {
                            final updated = await Navigator.push<bool>(
                              context,
                              MaterialPageRoute(
                                builder: (_) => EmployeeDetailScreen(
                                    employeeId: employees[i].id),
                              ),
                            );
                            if (updated == true && context.mounted) {
                              context.read<EmployeeCubit>().loadEmployees();
                            }
                          },
                          onArchive: () =>
                              context.read<EmployeeCubit>().deleteEmployee(employees[i].id),
                          onDelete: () =>
                              context.read<EmployeeCubit>().removeEmployee(employees[i].id),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
