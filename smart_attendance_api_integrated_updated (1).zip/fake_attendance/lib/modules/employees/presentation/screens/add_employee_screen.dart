import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:smart_attendance/core/constants/app_constants.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';
import 'package:uuid/uuid.dart';

class AddEmployeeScreen extends StatefulWidget {
  final EmployeeModel? employee;

  const AddEmployeeScreen({super.key, this.employee});

  @override
  State<AddEmployeeScreen> createState() => _AddEmployeeScreenState();
}

class _AddEmployeeScreenState extends State<AddEmployeeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _positionCtrl = TextEditingController();
  final _departmentCtrl = TextEditingController();
  final _salaryCtrl = TextEditingController();

  DateTime _dateOfBirth = DateTime(1995, 1, 1);
  bool _loading = false;
  bool get _isEditing => widget.employee != null;

  final ImagePicker _imagePicker = ImagePicker();
  File? _selectedImage;
  bool _uploadingPhoto = false;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      final e = widget.employee!;
      _nameCtrl.text = e.name;
      _emailCtrl.text = e.email;
      _phoneCtrl.text = e.phone;
      _positionCtrl.text = e.position;
      _departmentCtrl.text = e.department;
      _salaryCtrl.text = e.salary?.toString() ?? '';
      if (e.dateOfBirth != null) _dateOfBirth = e.dateOfBirth!;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _positionCtrl.dispose();
    _departmentCtrl.dispose();
    _salaryCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Take a photo'),
              onTap: () => Navigator.of(sheetContext).pop(ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Choose from gallery'),
              onTap: () => Navigator.of(sheetContext).pop(ImageSource.gallery),
            ),
          ],
        ),
      ),
    );

    if (source == null) return;

    try {
      final picked = await _imagePicker.pickImage(
        source: source,
        imageQuality: 85,
        maxWidth: 1280,
      );
      if (picked == null) return;
      setState(() => _selectedImage = File(picked.path));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not pick an image: $e'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _loading = true);

    final repo = getIt<EmployeeRepository>();
    final employee = EmployeeModel(
      id: _isEditing ? widget.employee!.id : const Uuid().v4(),
      name: _nameCtrl.text.trim(),
      email: _emailCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(),
      position: _positionCtrl.text.trim(),
      department: _departmentCtrl.text.trim(),
      address: widget.employee?.address,
      salary: _salaryCtrl.text.trim().isEmpty
          ? null
          : double.tryParse(_salaryCtrl.text.trim()),
      joiningDate: _isEditing ? widget.employee!.joiningDate : DateTime.now(),
      dateOfBirth: _dateOfBirth,
      photoUrl: widget.employee?.photoUrl,
      createdAt: _isEditing ? widget.employee!.createdAt : DateTime.now(),
    );

    // Only the seven fields the backend accepts are sent:
    // name, email, phoneNumber, dateOfBirth, salary, department, jobTitle.
    final requestData = {
      'name': employee.name,
      'email': employee.email,
      'phoneNumber': employee.phone,
      'dateOfBirth': employee.dateOfBirth,
      'salary': employee.salary,
      'department': employee.department,
      'jobTitle': employee.position,
    };

    final result = _isEditing
        ? await repo.updateEmployee(employee.id, requestData)
        : await repo.addEmployee(requestData);

    await result.fold(
      (f) async {
        setState(() => _loading = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(f.message),
              backgroundColor: Theme.of(context).colorScheme.error,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      },
      (saved) async {
        // Employee record saved. If the user picked a new photo, upload it
        // now that we have a real (backend-issued) employee id to attach it
        // to.
        if (_selectedImage != null) {
          setState(() => _uploadingPhoto = true);
          final photoResult = await repo.uploadEmployeePhoto(saved.id, _selectedImage!);
          setState(() => _uploadingPhoto = false);

          photoResult.fold(
            (f) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Employee saved, but the photo upload failed: ${f.message}'),
                    backgroundColor: Theme.of(context).colorScheme.error,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            (_) {},
          );
        }

        setState(() => _loading = false);
        if (mounted) Navigator.of(context).pop(true);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final String? existingPhotoUrl = widget.employee?.photoUrl;

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Employee' : 'Add Employee'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Photo Picker
              Center(
                child: GestureDetector(
                  onTap: _uploadingPhoto ? null : _pickPhoto,
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: 56,
                        backgroundColor: cs.primary.withValues(alpha: 0.1),
                        backgroundImage: _selectedImage != null
                            ? FileImage(_selectedImage!)
                            : (existingPhotoUrl != null &&
                                    existingPhotoUrl.isNotEmpty)
                                ? NetworkImage(existingPhotoUrl) as ImageProvider
                                : null,
                        child: (_selectedImage == null &&
                                (existingPhotoUrl == null ||
                                    existingPhotoUrl.isEmpty))
                            ? Icon(Icons.person_add_outlined,
                                size: 40, color: cs.primary)
                            : null,
                      ),
                      if (_uploadingPhoto)
                        Positioned.fill(
                          child: CircleAvatar(
                            radius: 56,
                            backgroundColor: Colors.black.withValues(alpha: 0.4),
                            child: const SizedBox(
                              height: 28,
                              width: 28,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2.5, color: Colors.white),
                            ),
                          ),
                        ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: cs.primary,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.camera_alt,
                              color: Colors.white, size: 16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 28),

              _buildField('Full Name', _nameCtrl,
                  hint: 'John Doe',
                  icon: Icons.person_outline,
                  validator: (v) => v!.trim().isEmpty ? 'Name is required' : null),
              const SizedBox(height: 16),

              _buildField('Email', _emailCtrl,
                  hint: 'john@company.com',
                  icon: Icons.email_outlined,
                  type: TextInputType.emailAddress,
                  validator: (v) {
                    if (v!.trim().isEmpty) return 'Email is required';
                    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(v.trim())) {
                      return 'Enter a valid email';
                    }
                    return null;
                  }),
              const SizedBox(height: 16),

              _buildField('Phone Number', _phoneCtrl,
                  hint: '+1 234 567 8900',
                  icon: Icons.phone_outlined,
                  type: TextInputType.phone,
                  validator: (v) => v!.trim().isEmpty ? 'Phone number is required' : null),
              const SizedBox(height: 16),

              _buildField('Job Title', _positionCtrl,
                  hint: 'Software Engineer',
                  icon: Icons.work_outline,
                  validator: (v) => v!.trim().isEmpty ? 'Job title is required' : null),
              const SizedBox(height: 16),

              _buildField('Department', _departmentCtrl,
                  hint: 'Engineering',
                  icon: Icons.business_outlined,
                  validator: (v) => v!.trim().isEmpty ? 'Department is required' : null),
              const SizedBox(height: 16),

              _buildField('Salary (Optional)', _salaryCtrl,
                  hint: '5000',
                  icon: Icons.attach_money,
                  type: TextInputType.number),
              const SizedBox(height: 16),

              // Date of Birth (required by backend CreateEmployeeRequest)
              GestureDetector(
                onTap: () async {
                  final d = await showDatePicker(
                    context: context,
                    initialDate: _dateOfBirth,
                    firstDate: DateTime(1950),
                    lastDate: DateTime.now(),
                  );
                  if (d != null) setState(() => _dateOfBirth = d);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  decoration: BoxDecoration(
                    color: theme.inputDecorationTheme.fillColor,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF2E4057)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.cake_outlined, color: cs.onSurface.withValues(alpha: 0.5)),
                      const SizedBox(width: 12),
                      Text('Date of Birth: ${DateFormat('MMM dd, yyyy').format(_dateOfBirth)}',
                          style: theme.textTheme.bodyLarge),
                      const Spacer(),
                      Icon(Icons.arrow_drop_down, color: cs.onSurface.withValues(alpha: 0.5)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 32),

              ElevatedButton(
                onPressed: _loading ? null : _submit,
                child: _loading
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.5, color: Colors.white),
                      )
                    : Text(_isEditing ? 'Save Changes' : 'Add Employee'),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    String label,
    TextEditingController ctrl, {
    String? hint,
    IconData? icon,
    TextInputType type = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 8),
        TextFormField(
          controller: ctrl,
          keyboardType: type,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: icon != null ? Icon(icon) : null,
          ),
          validator: validator,
        ),
      ],
    );
  }
}
