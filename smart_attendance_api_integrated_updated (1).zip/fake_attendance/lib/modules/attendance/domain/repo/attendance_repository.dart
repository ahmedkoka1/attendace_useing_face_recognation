import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_submission_model.dart';

abstract class AttendanceRepository {
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByDate(DateTime date);
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByEmployee(String employeeId);

  /// Legacy in-memory demo flow (no image, no REST call). Still used by
  /// screens that haven't been migrated to the camera + REST flow yet.
  Future<Either<Failure, AttendanceModel>> markAttendance({
    required String employeeId,
    required AttendanceStatus status,
    DateTime? checkIn,
    DateTime? checkOut,
    String? notes,
  });

  Future<Either<Failure, void>> updateAttendance(String id, AttendanceStatus status, String? notes);

  /// Submits a check-in/check-out record together with the captured photo
  /// to the backend via `POST /api/attendance` (multipart/form-data).
  ///
  /// - [onSendProgress] reports upload progress (bytes sent / total) so the
  ///   UI can render a progress indicator.
  /// - If the device is offline, the submission is queued locally (image
  ///   kept on disk) and retried automatically once connectivity returns,
  ///   instead of failing outright.
  Future<Either<Failure, AttendanceModel>> submitAttendance(
    AttendanceSubmissionModel submission, {
    void Function(int sent, int total)? onSendProgress,
  });

  /// Attempts to upload any attendance submissions that were queued while
  /// the device was offline. Safe to call repeatedly (e.g. on connectivity
  /// change); it's a no-op when the queue is empty.
  Future<void> syncPendingAttendance();

  /// Whether there are submissions currently waiting to be uploaded.
  Future<bool> get hasPendingSubmissions;
}
