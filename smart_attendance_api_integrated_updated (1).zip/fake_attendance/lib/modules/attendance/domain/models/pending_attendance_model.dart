import 'package:smart_attendance/modules/attendance/domain/models/attendance_type.dart';

/// A queued attendance submission that could not be sent immediately
/// because the device was offline. Stored as JSON in SharedPreferences; the
/// captured photo itself is kept on disk at [imagePath] (see
/// `AttendanceOfflineQueue`) and only deleted once the upload succeeds -
/// this is the "store the image locally... if offline mode is enabled"
/// behavior requested in the spec.
class PendingAttendanceModel {
  final String id;
  final String employeeId;
  final AttendanceType attendanceType;
  final DateTime timestamp;
  final String imagePath;
  final double? latitude;
  final double? longitude;
  final String? deviceId;

  const PendingAttendanceModel({
    required this.id,
    required this.employeeId,
    required this.attendanceType,
    required this.timestamp,
    required this.imagePath,
    this.latitude,
    this.longitude,
    this.deviceId,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'employeeId': employeeId,
        'attendanceType': attendanceType.apiValue,
        'timestamp': timestamp.toIso8601String(),
        'imagePath': imagePath,
        'latitude': latitude,
        'longitude': longitude,
        'deviceId': deviceId,
      };

  factory PendingAttendanceModel.fromJson(Map<String, dynamic> json) {
    return PendingAttendanceModel(
      id: json['id'] as String,
      employeeId: json['employeeId'] as String,
      attendanceType: AttendanceType.fromApiValue(json['attendanceType'] as String),
      timestamp: DateTime.parse(json['timestamp'] as String),
      imagePath: json['imagePath'] as String,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      deviceId: json['deviceId'] as String?,
    );
  }
}
