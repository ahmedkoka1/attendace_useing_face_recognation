enum AttendanceStatus { present, absent, late, earlyLeave, leave }

class AttendanceModel {
  final String id;
  final String employeeId;
  final String employeeName;
  final String employeePhotoUrl;
  final String department;
  final DateTime date;
  final DateTime? checkIn;
  final DateTime? checkOut;
  final AttendanceStatus status;
  final double? workingHours;
  final String? notes;

  const AttendanceModel({
    required this.id,
    required this.employeeId,
    required this.employeeName,
    this.employeePhotoUrl = '',
    required this.department,
    required this.date,
    this.checkIn,
    this.checkOut,
    required this.status,
    this.workingHours,
    this.notes,
  });

  String get formattedCheckIn {
    if (checkIn == null) return '--:--';
    return '${checkIn!.hour.toString().padLeft(2, '0')}:${checkIn!.minute.toString().padLeft(2, '0')}';
  }

  String get formattedCheckOut {
    if (checkOut == null) return '--:--';
    return '${checkOut!.hour.toString().padLeft(2, '0')}:${checkOut!.minute.toString().padLeft(2, '0')}';
  }

  String get formattedWorkingHours {
    if (workingHours == null) return '--';
    final h = workingHours!.floor();
    final m = ((workingHours! - h) * 60).round();
    return '${h}h ${m}m';
  }
}
