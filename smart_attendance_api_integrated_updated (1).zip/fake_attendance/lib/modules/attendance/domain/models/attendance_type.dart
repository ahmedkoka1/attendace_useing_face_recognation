/// Type of attendance action being submitted to the backend. The backend
/// decides how to persist the record (as a check-in or check-out) based on
/// this value - the app never encodes that business logic itself.
enum AttendanceType {
  checkIn,
  checkOut;

  /// Value sent to the backend in the `attendanceType` field.
  String get apiValue => switch (this) {
        AttendanceType.checkIn => 'check_in',
        AttendanceType.checkOut => 'check_out',
      };

  String get label => switch (this) {
        AttendanceType.checkIn => 'Check In',
        AttendanceType.checkOut => 'Check Out',
      };

  static AttendanceType fromApiValue(String value) {
    return value == 'check_out' ? AttendanceType.checkOut : AttendanceType.checkIn;
  }
}
