import 'dart:io';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_type.dart';

/// Everything required to submit one attendance action (check-in or
/// check-out) to the backend. Built by the presentation layer once the
/// photo has been captured and passed down to the repository unchanged.
class AttendanceSubmissionModel {
  final String employeeId;
  final AttendanceType attendanceType;
  final DateTime timestamp;
  final File imageFile;
  final double? latitude;
  final double? longitude;
  final String? deviceId;

  const AttendanceSubmissionModel({
    required this.employeeId,
    required this.attendanceType,
    required this.timestamp,
    required this.imageFile,
    this.latitude,
    this.longitude,
    this.deviceId,
  });

  AttendanceSubmissionModel copyWith({File? imageFile}) {
    return AttendanceSubmissionModel(
      employeeId: employeeId,
      attendanceType: attendanceType,
      timestamp: timestamp,
      imageFile: imageFile ?? this.imageFile,
      latitude: latitude,
      longitude: longitude,
      deviceId: deviceId,
    );
  }
}
