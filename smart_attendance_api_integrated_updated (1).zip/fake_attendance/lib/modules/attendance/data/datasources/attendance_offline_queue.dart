import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_submission_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/pending_attendance_model.dart';

/// Persists attendance submissions that couldn't be sent immediately
/// because the device was offline ("offline mode").
///
/// Design: submissions are almost always sent live. Only when there is no
/// connectivity at submit time does this queue come into play - the
/// captured photo is copied into permanent app storage (so it survives the
/// temp-file cleanup) and the record's metadata is stored as JSON in
/// SharedPreferences. Both are deleted as soon as the item uploads
/// successfully, matching "do not store the image locally after a
/// successful upload".
class AttendanceOfflineQueue {
  static const _prefsKey = 'pending_attendance_queue';

  Future<Directory> _queueDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final queueDir = Directory('${dir.path}/pending_attendance');
    if (!await queueDir.exists()) await queueDir.create(recursive: true);
    return queueDir;
  }

  /// Copies the captured image into permanent storage and stores the
  /// submission's metadata for later retry. Returns the queued item.
  Future<PendingAttendanceModel> enqueue(AttendanceSubmissionModel submission) async {
    final dir = await _queueDir();
    final id = '${submission.employeeId}_${submission.timestamp.millisecondsSinceEpoch}';
    final savedImage = await submission.imageFile.copy('${dir.path}/$id.jpg');

    final pending = PendingAttendanceModel(
      id: id,
      employeeId: submission.employeeId,
      attendanceType: submission.attendanceType,
      timestamp: submission.timestamp,
      imagePath: savedImage.path,
      latitude: submission.latitude,
      longitude: submission.longitude,
      deviceId: submission.deviceId,
    );

    final all = await getAll();
    all.add(pending);
    await _save(all);
    return pending;
  }

  Future<List<PendingAttendanceModel>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_prefsKey) ?? [];
    return raw
        .map((s) => PendingAttendanceModel.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
  }

  Future<void> _save(List<PendingAttendanceModel> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _prefsKey,
      items.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  /// Removes a successfully-uploaded item from the queue and deletes its
  /// locally-stored image.
  Future<void> remove(String id) async {
    final all = await getAll();
    final matches = all.where((e) => e.id == id);
    final item = matches.isEmpty ? null : matches.first;
    all.removeWhere((e) => e.id == id);
    await _save(all);
    if (item != null) {
      final file = File(item.imagePath);
      if (await file.exists()) await file.delete();
    }
  }

  Future<bool> get hasPending async => (await getAll()).isNotEmpty;
}
