import 'package:smart_attendance/core/constants/api_constants.dart';
import 'package:smart_attendance/core/network/api_client.dart';
import 'package:smart_attendance/core/network/api_exceptions.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_submission_model.dart';

/// Talks to the backend's `/attendance` REST endpoint(s). This is the only
/// class in the app that knows about the wire format (field names,
/// multipart encoding, JSON shape of the response) - everything above it
/// works with plain Dart models.
abstract class AttendanceRemoteDataSource {
  /// GET /api/attendance/employee/{employeeId} - the only attendance-read
  /// endpoint the backend actually exposes.
  Future<List<AttendanceModel>> getAttendanceByEmployee(String employeeId);

  /// Uploads [submission] as `multipart/form-data`. [onSendProgress]
  /// reports bytes sent / total bytes so the UI can render a progress bar.
  ///
  /// Throws an [ApiException] subtype on any failure (network, timeout,
  /// 4xx/5xx, etc.) - callers should not need to inspect Dio types.
  ///
  /// ** BACKEND GAP **: there is no `POST /api/attendance` (or any other
  /// endpoint) on this backend that accepts a check-in/out submission with
  /// an image from a mobile client. The only write-side attendance-like
  /// endpoint is `POST /api/face-events`, which takes JSON
  /// (employeeId/date/time/status, no image) and reads as a webhook meant
  /// for an external face-recognition device/service to call - not
  /// something this app should call pretending to be that device. Calling
  /// it here would be guessing at a contract nobody documented, so this
  /// throws immediately with an explanatory error instead of hitting a
  /// URL that doesn't exist.
  Future<AttendanceModel> submitAttendance(
    AttendanceSubmissionModel submission, {
    void Function(int sent, int total)? onSendProgress,
  });
}

class AttendanceRemoteDataSourceImpl implements AttendanceRemoteDataSource {
  final ApiClient _apiClient;
  AttendanceRemoteDataSourceImpl(this._apiClient);

  @override
  Future<List<AttendanceModel>> getAttendanceByEmployee(String employeeId) async {
    try {
      final response = await _apiClient.dio.get(
        ApiConstants.attendanceByEmployeeEndpoint(employeeId),
      );
      final data = response.data;
      final list = (data is Map && data['data'] is List)
          ? data['data'] as List
          : (data is List ? data : const []);
      return list
          .whereType<Map>()
          .map((e) => _fromJson(Map<String, dynamic>.from(e), employeeId))
          .toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiClient.mapError(e);
    }
  }

  /// Maps a raw attendance JSON record into [AttendanceModel]. The exact
  /// response shape wasn't visible in the Swagger screenshots provided
  /// (only request DTOs were shown), so this reads defensively across a
  /// few plausible key names - verify against the live Swagger JSON once
  /// reachable.
  AttendanceModel _fromJson(Map<String, dynamic> json, String employeeId) {
    DateTime parseDateTime(dynamic dateVal, dynamic timeVal) {
      if (dateVal == null) return DateTime.now();
      final datePart = DateTime.tryParse(dateVal.toString()) ?? DateTime.now();
      if (timeVal == null) return datePart;
      final timeStr = timeVal.toString();
      final parts = timeStr.split(':');
      if (parts.length >= 2) {
        return DateTime(
          datePart.year, datePart.month, datePart.day,
          int.tryParse(parts[0]) ?? 0, int.tryParse(parts[1]) ?? 0,
        );
      }
      return datePart;
    }

    final statusStr = (json['status'] ?? '').toString().toLowerCase();
    final status = switch (statusStr) {
      'present' => AttendanceStatus.present,
      'late' => AttendanceStatus.late,
      'absent' => AttendanceStatus.absent,
      'leave' => AttendanceStatus.leave,
      'early_leave' || 'earlyleave' => AttendanceStatus.earlyLeave,
      _ => AttendanceStatus.present,
    };

    final date = json['date'] != null
        ? (DateTime.tryParse(json['date'].toString()) ?? DateTime.now())
        : DateTime.now();

    return AttendanceModel(
      id: (json['id'] ?? '${employeeId}_${date.millisecondsSinceEpoch}').toString(),
      employeeId: (json['employeeId'] ?? employeeId).toString(),
      employeeName: (json['employeeName'] ?? '').toString(),
      department: (json['department'] ?? '').toString(),
      date: date,
      checkIn: json['checkIn'] != null ? parseDateTime(json['date'], json['checkIn']) : null,
      checkOut: json['checkOut'] != null ? parseDateTime(json['date'], json['checkOut']) : null,
      status: status,
    );
  }

  @override
  Future<AttendanceModel> submitAttendance(
    AttendanceSubmissionModel submission, {
    void Function(int sent, int total)? onSendProgress,
  }) async {
    throw const UnknownApiException(
      'This backend has no endpoint for submitting attendance with a photo '
      'from the mobile app. Only GET /api/attendance/employee/{employeeId} '
      '(read history) exists; POST /api/face-events is a JSON-only webhook '
      'without an image field, intended for an external face-recognition '
      'device rather than this app. Ask the backend team for a real '
      'check-in/out endpoint (e.g. POST /api/attendance) before this flow '
      'can be wired up.',
    );
  }
}

