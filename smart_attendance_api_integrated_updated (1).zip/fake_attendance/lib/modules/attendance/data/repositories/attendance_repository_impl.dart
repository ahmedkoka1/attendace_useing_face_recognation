import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/events/attendance_event_bus.dart';
import 'package:smart_attendance/core/network/api_exceptions.dart';
import 'package:smart_attendance/core/services/connectivity_service.dart';
import 'package:smart_attendance/modules/attendance/data/datasources/attendance_offline_queue.dart';
import 'package:smart_attendance/modules/attendance/data/datasources/attendance_remote_data_source.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_submission_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

class AttendanceRepositoryImpl implements AttendanceRepository {
  final AttendanceRemoteDataSource _remote;
  final AttendanceOfflineQueue _offlineQueue;
  final ConnectivityService _connectivity;
  final AttendanceEventBus _eventBus;
  final EmployeeRepository _employeeRepo;

  AttendanceRepositoryImpl({
    required AttendanceRemoteDataSource remoteDataSource,
    required AttendanceOfflineQueue offlineQueue,
    required ConnectivityService connectivity,
    required AttendanceEventBus eventBus,
    required EmployeeRepository employeeRepo,
  })  : _remote = remoteDataSource,
        _offlineQueue = offlineQueue,
        _connectivity = connectivity,
        _eventBus = eventBus,
        _employeeRepo = employeeRepo;

  @override
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByEmployee(String employeeId) async {
    try {
      return Right(await _remote.getAttendanceByEmployee(employeeId));
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  /// ** BACKEND GAP **: there is no endpoint to list attendance for every
  /// employee on a given date - only `GET /attendance/employee/{id}` (one
  /// employee's full history) exists. To keep the Dashboard and
  /// "today's attendance" screens working without inventing a URL, this
  /// fetches the employee list, then fetches each employee's history and
  /// filters it to [date] client-side.
  ///
  /// This means one request per employee (N+1) - fine for a handful of
  /// employees, but ask the backend team for a proper
  /// `GET /attendance?date=...` endpoint if the employee count grows.
  @override
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByDate(DateTime date) async {
    try {
      final employeesResult = await _employeeRepo.getEmployees();
      return await employeesResult.fold(
        (f) async => Left(f),
        (employees) async {
          final all = <AttendanceModel>[];
          for (final emp in employees) {
            try {
              final records = await _remote.getAttendanceByEmployee(emp.id);
              all.addAll(records.where((r) =>
                  r.date.year == date.year &&
                  r.date.month == date.month &&
                  r.date.day == date.day));
            } catch (_) {
              // Skip employees whose history fails to load rather than
              // failing the whole dashboard.
              continue;
            }
          }
          return Right(all);
        },
      );
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  /// ** BACKEND GAP **: no endpoint exists to mark attendance directly
  /// (without a face-recognition photo event). See
  /// [AttendanceRemoteDataSource.submitAttendance] for details.
  @override
  Future<Either<Failure, AttendanceModel>> markAttendance({
    required String employeeId,
    required AttendanceStatus status,
    DateTime? checkIn,
    DateTime? checkOut,
    String? notes,
  }) async {
    return Left(Failure(
      message: 'Marking attendance manually is not supported by the current '
          'backend - there is no matching endpoint. Attendance appears to be '
          'recorded via the face-recognition device calling '
          'POST /api/face-events, not from this app.',
      type: FailureType.notFound,
    ));
  }

  @override
  Future<Either<Failure, void>> updateAttendance(String id, AttendanceStatus status, String? notes) async {
    return Left(Failure(
      message: 'Updating attendance is not supported by the current backend '
          '- no matching endpoint exists.',
      type: FailureType.notFound,
    ));
  }

  @override
  Future<Either<Failure, AttendanceModel>> submitAttendance(
    AttendanceSubmissionModel submission, {
    void Function(int sent, int total)? onSendProgress,
  }) async {
    try {
      final record = await _remote.submitAttendance(submission, onSendProgress: onSendProgress);
      _eventBus.publish(record);
      return Right(record);
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      return Left(Failure.fromException(e));
    }
  }

  @override
  Future<void> syncPendingAttendance() async {
    // No real submit endpoint exists yet (see submitAttendance above), so
    // there is nothing to sync. Left as a no-op rather than deleting the
    // offline-queue plumbing, since it will start working the moment the
    // backend exposes a real check-in/out endpoint.
    return;
  }

  @override
  Future<bool> get hasPendingSubmissions => _offlineQueue.hasPending;
}
