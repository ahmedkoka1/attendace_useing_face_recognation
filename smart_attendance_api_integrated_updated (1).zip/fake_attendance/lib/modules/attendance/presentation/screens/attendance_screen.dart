import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:smart_attendance/core/constants/app_constants.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/services/connectivity_service.dart';
import 'package:smart_attendance/core/services/device_info_service.dart';
import 'package:smart_attendance/core/services/image_compression_service.dart';
import 'package:smart_attendance/core/services/location_service.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_type.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/attendance/presentation/cubit/attendance_cubit.dart';
import 'package:smart_attendance/modules/attendance/presentation/widgets/upload_progress_indicator.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

class AttendanceScreen extends StatelessWidget {
  const AttendanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AttendanceCubit(
        getIt<AttendanceRepository>(),
        locationService: getIt<LocationService>(),
        deviceInfoService: getIt<DeviceInfoService>(),
        imageCompressionService: getIt<ImageCompressionService>(),
        connectivityService: getIt<ConnectivityService>(),
      )..loadTodayAttendance(),
      child: const _AttendanceView(),
    );
  }
}

class _AttendanceView extends StatelessWidget {
  const _AttendanceView();

  /// Converts a [Failure] into a user-friendly SnackBar, using the typed
  /// [FailureType] to add a relevant icon rather than string-matching the
  /// message (requirement 6: 400/401/404/500/network/upload errors).
  void _showFailureSnackBar(BuildContext context, Failure failure) {
    final cs = Theme.of(context).colorScheme;
    IconData icon;
    switch (failure.type) {
      case FailureType.network:
        icon = Icons.wifi_off_rounded;
        break;
      case FailureType.timeout:
        icon = Icons.timer_off_rounded;
        break;
      case FailureType.unauthorized:
        icon = Icons.lock_outline_rounded;
        break;
      case FailureType.notFound:
        icon = Icons.search_off_rounded;
        break;
      case FailureType.badRequest:
      case FailureType.validation:
        icon = Icons.error_outline_rounded;
        break;
      case FailureType.server:
        icon = Icons.dns_rounded;
        break;
      case FailureType.imageUpload:
        icon = Icons.image_not_supported_outlined;
        break;
      case FailureType.permission:
        icon = Icons.no_photography_rounded;
        break;
      case FailureType.unknown:
        icon = Icons.error_outline_rounded;
        break;
    }

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(failure.message)),
        ],
      ),
      backgroundColor: cs.error,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 4),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return BlocListener<AttendanceCubit, AttendanceState>(
      listener: (context, state) {
        if (state is AttendanceActionSuccessState) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(state.message),
            backgroundColor: const Color(AppColors.presentColor),
            behavior: SnackBarBehavior.floating,
          ));
          context.read<AttendanceCubit>().loadTodayAttendance();
        }
        if (state is AttendanceActionErrorState) {
          _showFailureSnackBar(context, state.failure);
        }
        if (state is AttendanceSubmissionResultState) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(state.wasQueued
                ? 'No connection - attendance saved and will sync automatically.'
                : '${state.record.employeeName.isEmpty ? 'Attendance' : state.record.employeeName} recorded successfully.'),
            backgroundColor: state.wasQueued
                ? const Color(AppColors.lateColor)
                : const Color(AppColors.presentColor),
            behavior: SnackBarBehavior.floating,
          ));
        }
        if (state is AttendanceSubmissionErrorState) {
          _showFailureSnackBar(context, state.failure);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Mark Attendance'),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () =>
                  context.read<AttendanceCubit>().loadTodayAttendance(),
            ),
          ],
        ),
        floatingActionButton: BlocBuilder<AttendanceCubit, AttendanceState>(
          builder: (context, state) {
            final busy = state is AttendancePreparingSubmissionState || state is AttendanceUploadingState;
            return FloatingActionButton.extended(
              onPressed: busy ? null : () => _showMarkDialog(context),
              icon: busy
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.camera_alt_outlined),
              label: Text(busy ? 'Submitting…' : 'Mark Attendance'),
            );
          },
        ),
        body: Column(
          children: [
            // Date Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              color: cs.primary.withValues(alpha: 0.08),
              child: Row(
                children: [
                  Icon(Icons.calendar_today, color: cs.primary, size: 18),
                  const SizedBox(width: 10),
                  Text(
                    DateFormat('EEEE, MMMM dd yyyy').format(DateTime.now()),
                    style: theme.textTheme.titleMedium?.copyWith(
                        color: cs.primary, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            Expanded(
              child: BlocBuilder<AttendanceCubit, AttendanceState>(
                builder: (context, state) {
                  if (state is AttendanceLoadingState) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (state is AttendanceErrorState) {
                    return Center(child: Text(state.failure.message));
                  }
                  if (state is AttendanceLoadedState) {
                    if (state.records.isEmpty) {
                      return Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.event_busy,
                                size: 72,
                                color: cs.onSurface.withValues(alpha: 0.2)),
                            const SizedBox(height: 16),
                            Text('No attendance recorded today',
                                style: theme.textTheme.titleMedium),
                          ],
                        ),
                      );
                    }
                    return ListView.separated(
                      padding:
                          const EdgeInsets.fromLTRB(16, 12, 16, 100),
                      itemCount: state.records.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) =>
                          _AttendanceRecordCard(record: state.records[i]),
                    );
                  }
                  return const SizedBox();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMarkDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BlocProvider.value(
        value: context.read<AttendanceCubit>(),
        child: const _MarkAttendanceDialog(),
      ),
    );
  }
}

class _MarkAttendanceDialog extends StatefulWidget {
  const _MarkAttendanceDialog();

  @override
  State<_MarkAttendanceDialog> createState() => _MarkAttendanceDialogState();
}

class _MarkAttendanceDialogState extends State<_MarkAttendanceDialog> {
  List<EmployeeModel> _employees = [];
  EmployeeModel? _selected;
  AttendanceType _type = AttendanceType.checkIn;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadEmployees();
  }

  Future<void> _loadEmployees() async {
    setState(() => _loading = true);
    final result = await getIt<EmployeeRepository>().getEmployees();
    result.fold(
      (_) {},
      (list) => setState(() => _employees = list),
    );
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AttendanceCubit, AttendanceState>(
      listener: (context, state) {
        // Close the dialog as soon as the submission finishes (success or
        // error) - the parent screen's BlocListener shows the SnackBar.
        if (state is AttendanceSubmissionResultState ||
            state is AttendanceSubmissionErrorState) {
          Navigator.of(context).pop();
        }
      },
      builder: (context, state) {
        final isPreparing = state is AttendancePreparingSubmissionState;
        final isUploading = state is AttendanceUploadingState;
        final busy = isPreparing || isUploading;

        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Mark Attendance'),
          content: _loading
              ? const SizedBox(
                  height: 80,
                  child: Center(child: CircularProgressIndicator()))
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<EmployeeModel>(
                      value: _selected,
                      hint: const Text('Select Employee'),
                      isExpanded: true,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.person_outline),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      items: _employees
                          .map((e) => DropdownMenuItem(
                              value: e,
                              child: Text(e.name, overflow: TextOverflow.ellipsis)))
                          .toList(),
                      onChanged: busy ? null : (e) => setState(() => _selected = e),
                    ),
                    const SizedBox(height: 14),
                    SegmentedButton<AttendanceType>(
                      segments: const [
                        ButtonSegment(
                          value: AttendanceType.checkIn,
                          label: Text('Check In'),
                          icon: Icon(Icons.login),
                        ),
                        ButtonSegment(
                          value: AttendanceType.checkOut,
                          label: Text('Check Out'),
                          icon: Icon(Icons.logout),
                        ),
                      ],
                      selected: {_type},
                      onSelectionChanged: busy
                          ? null
                          : (s) => setState(() => _type = s.first),
                    ),
                    if (isPreparing) ...[
                      const SizedBox(height: 16),
                      const Row(
                        children: [
                          SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                          SizedBox(width: 10),
                          Text('Opening camera…'),
                        ],
                      ),
                    ],
                    if (isUploading) ...[
                      const SizedBox(height: 16),
                      UploadProgressIndicator(progress: state.progress),
                    ],
                  ],
                ),
          actions: [
            TextButton(
                onPressed: busy ? null : () => Navigator.pop(context),
                child: const Text('Cancel')),
            ElevatedButton.icon(
              onPressed: (_selected == null || busy)
                  ? null
                  : () {
                      context.read<AttendanceCubit>().captureAndSubmitAttendance(
                            employeeId: _selected!.id,
                            attendanceType: _type,
                          );
                    },
              icon: const Icon(Icons.camera_alt_outlined, size: 18),
              style: ElevatedButton.styleFrom(minimumSize: const Size(160, 44)),
              label: Text(_type == AttendanceType.checkIn ? 'Capture & Check In' : 'Capture & Check Out'),
            ),
          ],
        );
      },
    );
  }
}

class _AttendanceRecordCard extends StatelessWidget {
  final AttendanceModel record;

  const _AttendanceRecordCard({required this.record});

  Color _statusColor() {
    switch (record.status) {
      case AttendanceStatus.present:
        return const Color(AppColors.presentColor);
      case AttendanceStatus.absent:
        return const Color(AppColors.absentColor);
      case AttendanceStatus.late:
        return const Color(AppColors.lateColor);
      default:
        return const Color(AppColors.leaveColor);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = _statusColor();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: color.withValues(alpha: 0.15),
              backgroundImage: record.employeePhotoUrl.isNotEmpty
                  ? null
                  : null,
              child: record.employeePhotoUrl.isEmpty
                  ? Text(
                      record.employeeName.isNotEmpty ? record.employeeName[0].toUpperCase() : '?',
                      style: TextStyle(
                          color: color, fontWeight: FontWeight.w700))
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(record.employeeName.isNotEmpty ? record.employeeName : record.employeeId,
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(Icons.login, size: 13,
                          color: const Color(AppColors.presentColor)),
                      const SizedBox(width: 4),
                      Text(record.formattedCheckIn,
                          style: theme.textTheme.bodySmall),
                      if (record.checkOut != null) ...[
                        const SizedBox(width: 10),
                        Icon(Icons.logout, size: 13,
                            color: const Color(AppColors.absentColor)),
                        const SizedBox(width: 4),
                        Text(record.formattedCheckOut,
                            style: theme.textTheme.bodySmall),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(record.status.name,
                  style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }
}
