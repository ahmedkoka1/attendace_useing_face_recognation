import 'package:flutter/material.dart';

/// Small reusable widget showing upload progress (0.0-1.0) with a
/// percentage label. Used while an attendance photo is being sent to the
/// backend.
class UploadProgressIndicator extends StatelessWidget {
  final double progress;
  final String label;

  const UploadProgressIndicator({
    super.key,
    required this.progress,
    this.label = 'Uploading photo…',
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final percent = (progress.clamp(0.0, 1.0) * 100).round();

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: theme.textTheme.bodyMedium),
            Text('$percent%', style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: progress <= 0 ? null : progress.clamp(0.0, 1.0),
            minHeight: 8,
          ),
        ),
      ],
    );
  }
}
