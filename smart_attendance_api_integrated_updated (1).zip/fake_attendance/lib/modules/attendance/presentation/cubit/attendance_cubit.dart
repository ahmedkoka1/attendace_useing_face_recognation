import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/services/connectivity_service.dart';
import 'package:smart_attendance/core/services/device_info_service.dart';
import 'package:smart_attendance/core/services/image_compression_service.dart';
import 'package:smart_attendance/core/services/location_service.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_submission_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_type.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';

abstract class AttendanceState extends Equatable {
  @override List<Object?> get props => [];
}
class AttendanceInitialState extends AttendanceState {}
class AttendanceLoadingState extends AttendanceState {}
class AttendanceLoadedState extends AttendanceState {
  final List<AttendanceModel> records;
  AttendanceLoadedState(this.records);
  @override List<Object?> get props => [records.length];
}
class AttendanceErrorState extends AttendanceState {
  final Failure failure;
  AttendanceErrorState(this.failure);
  @override List<Object?> get props => [failure.message];
}
class AttendanceActionSuccessState extends AttendanceState {
  final String message;
  final AttendanceModel record;
  AttendanceActionSuccessState(this.message, this.record);
}
class AttendanceActionErrorState extends AttendanceState {
  final Failure failure;
  AttendanceActionErrorState(this.failure);
}

/// Emitted while a photo is being captured/compressed, before the upload
/// itself begins.
class AttendancePreparingSubmissionState extends AttendanceState {}

/// Emitted repeatedly during the multipart upload with progress in the
/// 0.0-1.0 range, so the UI can render a progress bar.
class AttendanceUploadingState extends AttendanceState {
  final double progress;
  AttendanceUploadingState(this.progress);
  @override List<Object?> get props => [progress];
}

/// Emitted after a successful REST submission (whether it uploaded live or
/// was queued for offline sync - see [AttendanceSubmissionResultState.wasQueued]).
class AttendanceSubmissionResultState extends AttendanceState {
  final AttendanceModel record;
  final bool wasQueued;
  AttendanceSubmissionResultState(this.record, {required this.wasQueued});
}

class AttendanceSubmissionErrorState extends AttendanceState {
  final Failure failure;
  AttendanceSubmissionErrorState(this.failure);
}

class AttendanceCubit extends Cubit<AttendanceState> {
  final AttendanceRepository _repo;
  final LocationService _locationService;
  final DeviceInfoService _deviceInfoService;
  final ImageCompressionService _imageCompressionService;
  final ConnectivityService _connectivityService;
  final ImagePicker _imagePicker;

  /// Prevents a second submission from starting while one is already in
  /// flight (satisfies "Prevent duplicate attendance submissions while an
  /// upload is in progress").
  bool _isSubmitting = false;
  bool get isSubmitting => _isSubmitting;

  AttendanceCubit(
    this._repo, {
    required LocationService locationService,
    required DeviceInfoService deviceInfoService,
    required ImageCompressionService imageCompressionService,
    required ConnectivityService connectivityService,
    ImagePicker? imagePicker,
  })  : _locationService = locationService,
        _deviceInfoService = deviceInfoService,
        _imageCompressionService = imageCompressionService,
        _connectivityService = connectivityService,
        _imagePicker = imagePicker ?? ImagePicker(),
        super(AttendanceInitialState()) {
    // Best-effort: flush anything queued from a previous offline session as
    // soon as this cubit is created and the device happens to be online.
    _repo.syncPendingAttendance();
  }

  Future<void> loadTodayAttendance() async {
    emit(AttendanceLoadingState());
    final result = await _repo.getAttendanceByDate(DateTime.now());
    result.fold(
      (f) => emit(AttendanceErrorState(f)),
      (records) => emit(AttendanceLoadedState(records)),
    );
  }

  // ---------------------------------------------------------------------
  // Legacy demo flow (kept for backward compatibility with any screen
  // still calling it without a captured photo).
  // ---------------------------------------------------------------------

  Future<void> checkIn({
    required String employeeId,
    required String employeeName,
    required String department,
    String? photoUrl,
  }) async {
    emit(AttendanceLoadingState());
    final result = await _repo.markAttendance(
      employeeId: employeeId,
      status: AttendanceStatus.present,
      checkIn: DateTime.now(),
    );
    result.fold(
      (f) => emit(AttendanceActionErrorState(f)),
      (record) => emit(AttendanceActionSuccessState('Check-in recorded', record)),
    );
  }

  Future<void> checkOut(String attendanceId) async {
    final currentState = state;
    AttendanceModel? existing;
    if (currentState is AttendanceLoadedState) {
      for (final r in currentState.records) {
        if (r.id == attendanceId) {
          existing = r;
          break;
        }
      }
    }

    if (existing == null) {
      emit(AttendanceActionErrorState(Failure(message: 'Attendance record not found')));
      return;
    }

    final result = await _repo.markAttendance(
      employeeId: existing.employeeId,
      status: existing.status,
      checkIn: existing.checkIn,
      checkOut: DateTime.now(),
      notes: existing.notes,
    );

    result.fold(
      (f) => emit(AttendanceActionErrorState(f)),
      (record) {
        emit(AttendanceActionSuccessState('Check-out recorded', record));
        loadTodayAttendance();
      },
    );
  }

  // ---------------------------------------------------------------------
  // New camera + REST submission flow.
  // ---------------------------------------------------------------------

  /// Captures a photo with the device camera and submits a check-in/out
  /// record (image + employee id + type + timestamp + GPS + device id) to
  /// the backend via multipart/form-data.
  ///
  /// Safe to call from a button's `onPressed` directly - it no-ops if a
  /// submission is already running.
  Future<void> captureAndSubmitAttendance({
    required String employeeId,
    required AttendanceType attendanceType,
  }) async {
    if (_isSubmitting) return;
    _isSubmitting = true;

    try {
      emit(AttendancePreparingSubmissionState());

      final pickedImage = await _imagePicker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        imageQuality: 90,
      );

      if (pickedImage == null) {
        // User cancelled the camera - not an error, just reset silently.
        emit(AttendanceInitialState());
        return;
      }

      final compressedImage = await _imageCompressionService.compress(File(pickedImage.path));

      // Location and device id are optional/best-effort by design.
      final location = await _locationService.getCurrentLocation();
      final deviceId = await _deviceInfoService.getDeviceId();

      final submission = AttendanceSubmissionModel(
        employeeId: employeeId,
        attendanceType: attendanceType,
        timestamp: DateTime.now(),
        imageFile: compressedImage,
        latitude: location?.latitude,
        longitude: location?.longitude,
        deviceId: deviceId,
      );

      final wasOnlineAtStart = await _connectivityService.isConnected;
      emit(AttendanceUploadingState(0));

      final result = await _repo.submitAttendance(
        submission,
        onSendProgress: (sent, total) {
          if (total <= 0) return;
          emit(AttendanceUploadingState(sent / total));
        },
      );

      result.fold(
        (failure) => emit(AttendanceSubmissionErrorState(failure)),
        (record) {
          emit(AttendanceSubmissionResultState(record, wasQueued: !wasOnlineAtStart));
          loadTodayAttendance();
        },
      );

      // Best-effort cleanup of the original (uncompressed) capture; the
      // compressed copy has already been uploaded or handed to the offline
      // queue (which makes its own permanent copy), so it's safe to delete.
      final original = File(pickedImage.path);
      if (await original.exists()) {
        await original.delete().catchError((_) => original);
      }
    } catch (e) {
      emit(AttendanceSubmissionErrorState(Failure.fromException(e)));
    } finally {
      _isSubmitting = false;
    }
  }

  Future<bool> get hasPendingOfflineSubmissions => _repo.hasPendingSubmissions;

  Future<void> syncPendingAttendance() => _repo.syncPendingAttendance();
}
