import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:open_file/open_file.dart';
import 'package:excel/excel.dart' hide Border;
import 'package:smart_attendance/core/constants/app_constants.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  DateTime _selectedDate = DateTime.now();
  String _reportType = 'Daily';
  bool _loading = false;
  List<AttendanceModel> _records = [];

  final _types = ['Daily', 'Weekly', 'Monthly'];

  Future<void> _loadData() async {
    setState(() => _loading = true);
    // Note: from/to range computation removed - actual query uses _selectedDate directly.

    // For daily we just get by date; for ranges we need all employee attendance
    // Using a simplified approach: get all attendance between from/to dates
    // by querying per-day (simplified for demo - in production use a range query)
    final result = await getIt<AttendanceRepository>()
        .getAttendanceByDate(_selectedDate);

    result.fold(
      (f) => ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(f.message), backgroundColor: Colors.red)),
      (list) => setState(() => _records = list),
    );
    setState(() => _loading = false);
  }

  Future<void> _exportPdf() async {
    setState(() => _loading = true);
    try {
      final pdf = pw.Document();
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(32),
          build: (ctx) => [
            pw.Header(
              level: 0,
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Smart Attendance Report',
                      style: pw.TextStyle(
                          fontSize: 20, fontWeight: pw.FontWeight.bold)),
                  pw.Text(DateFormat('MMM dd, yyyy').format(_selectedDate),
                      style: const pw.TextStyle(fontSize: 12)),
                ],
              ),
            ),
            pw.SizedBox(height: 16),
            pw.Text('Report Type: $_reportType',
                style: const pw.TextStyle(fontSize: 12)),
            pw.Text('Total Records: ${_records.length}',
                style: const pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 16),
            pw.TableHelper.fromTextArray(
              headerStyle:
                  pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
              cellStyle: const pw.TextStyle(fontSize: 9),
              headers: [
                'Employee',
                'Department',
                'Status',
                'Check In',
                'Check Out',
                'Hours'
              ],
              data: _records
                  .map((r) => [
                        r.employeeName,
                        r.department,
                        r.status.name,
                        r.formattedCheckIn,
                        r.formattedCheckOut,
                        r.formattedWorkingHours,
                      ])
                  .toList(),
            ),
          ],
        ),
      );

      final dir = await getApplicationDocumentsDirectory();
      final file = File(
          '${dir.path}/attendance_report_${DateFormat('yyyyMMdd').format(_selectedDate)}.pdf');
      await file.writeAsBytes(await pdf.save());
      await OpenFile.open(file.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('PDF export failed: $e')));
      }
    }
    setState(() => _loading = false);
  }

  Future<void> _exportExcel() async {
    setState(() => _loading = true);
    try {
      final excel = Excel.createExcel();
      final sheet = excel['Attendance Report'];

      // Header
      final headers = [
        'Employee Name',
        'Department',
        'Status',
        'Check In',
        'Check Out',
        'Working Hours',
        'Date'
      ];
      for (var i = 0; i < headers.length; i++) {
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0))
            .value = TextCellValue(headers[i]);
      }

      // Data rows
      for (var i = 0; i < _records.length; i++) {
        final r = _records[i];
        final row = [
          r.employeeName,
          r.department,
          r.status.name,
          r.formattedCheckIn,
          r.formattedCheckOut,
          r.formattedWorkingHours,
          DateFormat('yyyy-MM-dd').format(r.date),
        ];
        for (var j = 0; j < row.length; j++) {
          sheet
              .cell(CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1))
              .value = TextCellValue(row[j]);
        }
      }

      final dir = await getApplicationDocumentsDirectory();
      final filePath =
          '${dir.path}/attendance_report_${DateFormat('yyyyMMdd').format(_selectedDate)}.xlsx';
      final encoded = excel.encode();
      if (encoded != null) {
        await File(filePath).writeAsBytes(encoded);
        await OpenFile.open(filePath);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Excel export failed: $e')));
      }
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Reports')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Report Type Selector
            Text('Report Type', style: theme.textTheme.labelLarge),
            const SizedBox(height: 10),
            Row(
              children: _types.map((t) {
                final selected = _reportType == t;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(t),
                    selected: selected,
                    onSelected: (_) => setState(() => _reportType = t),
                    selectedColor: cs.primary.withValues(alpha: 0.2),
                    labelStyle: TextStyle(
                        color: selected ? cs.primary : null,
                        fontWeight: selected ? FontWeight.w600 : null),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            // Date Picker
            Text('Select Date', style: theme.textTheme.labelLarge),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _selectedDate,
                  firstDate: DateTime(2020),
                  lastDate: DateTime.now(),
                );
                if (d != null) setState(() => _selectedDate = d);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: theme.inputDecorationTheme.fillColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF2E4057)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.calendar_today, color: cs.primary),
                    const SizedBox(width: 12),
                    Text(DateFormat('EEEE, MMMM dd, yyyy').format(_selectedDate),
                        style: theme.textTheme.bodyLarge),
                    const Spacer(),
                    const Icon(Icons.arrow_drop_down),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Generate Button
            ElevatedButton.icon(
              onPressed: _loading ? null : _loadData,
              icon: const Icon(Icons.bar_chart),
              label: const Text('Generate Report'),
            ),
            const SizedBox(height: 20),

            // Results
            if (_records.isNotEmpty) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${_records.length} records found',
                      style: theme.textTheme.titleMedium),
                  Row(
                    children: [
                      OutlinedButton.icon(
                        onPressed: _loading ? null : _exportPdf,
                        icon: const Icon(Icons.picture_as_pdf, size: 16),
                        label: const Text('PDF'),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: _loading ? null : _exportExcel,
                        icon: const Icon(Icons.table_chart, size: 16),
                        label: const Text('Excel'),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.separated(
                  itemCount: _records.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final r = _records[i];
                    final statusColor = _statusColor(r.status);
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: statusColor.withValues(alpha: 0.15),
                          child: Text(r.employeeName[0].toUpperCase(),
                              style: TextStyle(color: statusColor,
                                  fontWeight: FontWeight.w700)),
                        ),
                        title: Text(r.employeeName,
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text('${r.department} · ${r.formattedCheckIn} – ${r.formattedCheckOut}'),
                        trailing: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: statusColor.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(r.status.name,
                              style: TextStyle(color: statusColor,
                                  fontWeight: FontWeight.w600, fontSize: 12)),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],

            if (_loading) const Expanded(child: Center(child: CircularProgressIndicator())),
          ],
        ),
      ),
    );
  }

  Color _statusColor(AttendanceStatus s) {
    switch (s) {
      case AttendanceStatus.present: return const Color(AppColors.presentColor);
      case AttendanceStatus.absent: return const Color(AppColors.absentColor);
      case AttendanceStatus.late: return const Color(AppColors.lateColor);
      default: return const Color(AppColors.leaveColor);
    }
  }
}
