import 'dart:convert';

import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/constants/api_constants.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/network/api_client.dart';
import 'package:smart_attendance/core/network/api_exceptions.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';

abstract class AuthRepository {
  Future<Either<Failure, AdminModel>> login(String email, String password);
  Future<Either<Failure, void>> logout();
  Future<Either<Failure, void>> sendPasswordReset(String email);
  Future<Either<Failure, AdminModel?>> getCurrentAdmin();
}

class AuthRepositoryImpl implements AuthRepository {
  final ApiClient _apiClient;
  AuthRepositoryImpl(this._apiClient);

  @override
  Future<Either<Failure, AdminModel>> login(String email, String password) async {
    try {
      // The backend's LoginRequest schema only has `username` + `password`
      // (see Swagger -> Schemas -> LoginRequest) - there is no email field.
      // The UI still labels this "Email" for the admin, so we send whatever
      // was typed there as the username.
      final response = await _apiClient.dio.post(
        ApiConstants.loginEndpoint,
        data: {
          'username': email.trim(),
          'password': password,
        },
      );

      final data = response.data;
      final map = (data is Map) ? data : <String, dynamic>{};

      // The backend's LoginResponse shape wasn't visible in the Swagger
      // screenshots provided, so this defensively looks for the token under
      // a few common key names rather than assuming one.
      final token = (map['token'] ?? map['accessToken'] ?? map['jwt'] ?? map['data']?['token'])
          ?.toString();

      if (token == null || token.isEmpty) {
        return Left(Failure(
          message: 'Login succeeded but no auth token was found in the response. '
              'Backend response shape may differ from what this app expects - '
              'please check the actual LoginResponse schema in Swagger.',
        ));
      }

      await _apiClient.saveAuthToken(token);

      return Right(_adminFromToken(token, fallbackUsername: email.trim()));
    } on ApiException catch (e) {
      return Left(e.toFailure());
    } catch (e) {
      // Any raw DioException (wrong credentials -> 401, timeout, no
      // internet, etc.) needs to go through ApiClient.mapError first,
      // otherwise its raw toString() (e.g. "DioException [bad response]:
      // ...") ends up shown directly to the user instead of a friendly
      // message.
      final apiException = ApiClient.mapError(e);
      final message = apiException is UnauthorizedException
          ? 'Invalid username or password.'
          : apiException.message;
      return Left(Failure(message: message, type: apiException.toFailure().type));
    }
  }

  @override
  Future<Either<Failure, void>> logout() async {
    await _apiClient.clearAuthToken();
    return const Right(null);
  }

  @override
  Future<Either<Failure, void>> sendPasswordReset(String email) async {
    // No password-reset endpoint exists in the backend Swagger (only
    // /auth/register and /auth/login under "Auth"). Reporting this rather
    // than guessing at a URL that may not exist.
    return Left(Failure(
      message: 'Password reset is not available: the backend has no '
          'password-reset endpoint yet.',
      type: FailureType.notFound,
    ));
  }

  @override
  Future<Either<Failure, AdminModel?>> getCurrentAdmin() async {
    final token = await _apiClient.getAuthToken();
    if (token == null || token.isEmpty) return const Right(null);
    return Right(_adminFromToken(token));
  }

  /// The backend doesn't expose a `GET /auth/me` endpoint, so the admin's
  /// identity is decoded straight from the JWT payload (id/username claims)
  /// if present, instead of guessing at a non-existent profile endpoint.
  AdminModel _adminFromToken(String token, {String? fallbackUsername}) {
    String id = 'admin';
    String username = fallbackUsername ?? 'admin';
    try {
      final parts = token.split('.');
      if (parts.length == 3) {
        final payload = utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
        final claims = jsonDecode(payload) as Map<String, dynamic>;
        id = (claims['nameid'] ?? claims['sub'] ?? claims['id'] ?? id).toString();
        username = (claims['unique_name'] ?? claims['name'] ?? claims['username'] ?? username)
            .toString();
      }
    } catch (_) {
      // Malformed/opaque token - fall back to the defaults above rather
      // than failing the whole login.
    }
    return AdminModel(
      id: id,
      name: username,
      email: username,
      companyName: 'Smart Company',
      role: 'admin',
    );
  }
}
