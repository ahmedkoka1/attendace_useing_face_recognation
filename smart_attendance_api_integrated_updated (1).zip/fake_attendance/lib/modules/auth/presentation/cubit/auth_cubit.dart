import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:smart_attendance/modules/auth/domain/repo/auth_repository.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';

part 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  final AuthRepository _repo;
  AuthCubit(this._repo) : super(AuthInitialState());

  void checkAuth() async {
    emit(AuthLoadingState());
    final result = await _repo.getCurrentAdmin();
    result.fold(
      (f) => emit(AuthUnauthenticatedState()),
      (admin) => admin != null
          ? emit(AuthAuthenticatedState(admin: admin))
          : emit(AuthUnauthenticatedState()),
    );
  }

  Future<void> login(String email, String password) async {
    emit(AuthLoadingState());
    final result = await _repo.login(email, password);
    result.fold(
      (f) => emit(AuthErrorState(message: f.message)),
      (admin) => emit(AuthAuthenticatedState(admin: admin)),
    );
  }

  Future<void> logout() async {
    await _repo.logout();
    emit(AuthUnauthenticatedState());
  }

  Future<void> sendPasswordReset(String email) async {
    final result = await _repo.sendPasswordReset(email);
    result.fold(
      (f) => emit(AuthErrorState(message: f.message)),
      (_) {},
    );
  }
}
