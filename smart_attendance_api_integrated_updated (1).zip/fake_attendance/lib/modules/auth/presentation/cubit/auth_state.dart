part of 'auth_cubit.dart';

abstract class AuthState extends Equatable {
  @override
  List<Object?> get props => [];
}

class AuthInitialState extends AuthState {}
class AuthLoadingState extends AuthState {}
class AuthUnauthenticatedState extends AuthState {}
class AuthErrorState extends AuthState {
  final String message;
  AuthErrorState({required this.message});
  @override List<Object?> get props => [message];
}
class AuthAuthenticatedState extends AuthState {
  final AdminModel admin;
  AuthAuthenticatedState({required this.admin});
  @override List<Object?> get props => [admin.id];
}
