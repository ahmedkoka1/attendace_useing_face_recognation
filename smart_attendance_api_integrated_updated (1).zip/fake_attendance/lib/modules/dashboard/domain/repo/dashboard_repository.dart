import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

abstract class DashboardRepository {
  Future<Either<Failure, DashboardStatsModel>> getDashboardStats(DateTime date);
}

/// ** BACKEND GAP **: there is no dashboard/stats endpoint on the backend.
/// Stats are computed client-side from real data: the employee list
/// (`GET /api/employees`) plus each employee's attendance history
/// (`GET /api/attendance/employee/{id}`, via [AttendanceRepository]),
/// filtered down to [date]. This replaces the old FakeDatabase-generated
/// numbers with real ones, at the cost of an N+1 request pattern - ask the
/// backend team for a proper `GET /api/dashboard/stats?date=...` endpoint
/// if this needs to scale.
class DashboardRepositoryImpl implements DashboardRepository {
  final EmployeeRepository _employeeRepo;
  final AttendanceRepository _attendanceRepo;

  DashboardRepositoryImpl(this._employeeRepo, this._attendanceRepo);

  @override
  Future<Either<Failure, DashboardStatsModel>> getDashboardStats(DateTime date) async {
    final employeesResult = await _employeeRepo.getEmployees();
    final attResult = await _attendanceRepo.getAttendanceByDate(date);

    return employeesResult.fold(
      (f) => Left(f),
      (employees) => attResult.fold(
        (f) => Left(f),
        (todayAtt) => Right(_buildStats(employees, todayAtt)),
      ),
    );
  }

  DashboardStatsModel _buildStats(List<EmployeeModel> employees, List<AttendanceModel> todayAtt) {
    final active = employees.where((e) => e.isActive).toList();
    final total = active.length;
    int present = 0, late = 0;
    for (final a in todayAtt) {
      if (a.status == AttendanceStatus.present) present++;
      if (a.status == AttendanceStatus.late) {
        present++;
        late++;
      }
    }
    final absent = total - present;
    final pct = total > 0 ? (present / total) * 100.0 : 0.0;

    final deptMap = <String, _DeptCount>{};
    for (final a in todayAtt) {
      deptMap.putIfAbsent(a.department, () => _DeptCount());
      deptMap[a.department]!.total++;
      if (a.status != AttendanceStatus.absent && a.status != AttendanceStatus.leave) {
        deptMap[a.department]!.present++;
      }
    }
    final deptStats = deptMap.entries
        .map((e) => DepartmentAttendanceStat(
              department: e.key,
              total: e.value.total,
              present: e.value.present,
              percentage: e.value.total > 0 ? (e.value.present / e.value.total) * 100 : 0,
            ))
        .toList();

    return DashboardStatsModel(
      totalEmployees: total,
      presentToday: present,
      absentToday: absent < 0 ? 0 : absent,
      lateToday: late,
      attendancePercentage: pct,
      // Monthly trend would need one GET per day per employee with the
      // current endpoints - too expensive to compute eagerly here, so it's
      // left empty rather than faked. Wire this up once a range-based
      // attendance endpoint exists.
      monthlyStats: const [],
      departmentStats: deptStats,
      lastUpdated: DateTime.now(),
    );
  }
}

class _DeptCount {
  int total = 0;
  int present = 0;
}
