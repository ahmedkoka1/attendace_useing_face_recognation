class DashboardStatsModel {
  final int totalEmployees;
  final int presentToday;
  final int absentToday;
  final int lateToday;
  final double attendancePercentage;
  final List<MonthlyAttendanceStat> monthlyStats;
  final List<DepartmentAttendanceStat> departmentStats;
  final DateTime lastUpdated;

  const DashboardStatsModel({
    required this.totalEmployees,
    required this.presentToday,
    required this.absentToday,
    required this.lateToday,
    required this.attendancePercentage,
    required this.monthlyStats,
    required this.departmentStats,
    required this.lastUpdated,
  });

  factory DashboardStatsModel.empty() {
    return DashboardStatsModel(
      totalEmployees: 0, presentToday: 0, absentToday: 0, lateToday: 0,
      attendancePercentage: 0, monthlyStats: [], departmentStats: [],
      lastUpdated: DateTime.now(),
    );
  }
}

class MonthlyAttendanceStat {
  final int day;
  final double percentage;
  const MonthlyAttendanceStat({required this.day, required this.percentage});
}

class DepartmentAttendanceStat {
  final String department;
  final int total;
  final int present;
  final double percentage;
  const DepartmentAttendanceStat({
    required this.department, required this.total,
    required this.present, required this.percentage,
  });
}

class AdminModel {
  final String id;
  final String name;
  final String email;
  final String? photoUrl;
  final String companyName;
  final String role;

  const AdminModel({
    required this.id, required this.name, required this.email,
    this.photoUrl, required this.companyName, required this.role,
  });
}
