import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/events/attendance_event_bus.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';
import 'package:smart_attendance/modules/dashboard/domain/repo/dashboard_repository.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';

abstract class DashboardState extends Equatable {
  @override List<Object?> get props => [];
}
class DashboardInitialState extends DashboardState {}
class DashboardLoadingState extends DashboardState {}
class DashboardLoadedState extends DashboardState {
  final DashboardStatsModel stats;
  final List<AttendanceModel> todayAttendance;
  final DateTime selectedDate;
  DashboardLoadedState({required this.stats, required this.todayAttendance, required this.selectedDate});
  @override List<Object?> get props => [stats.lastUpdated, selectedDate];
}
class DashboardErrorState extends DashboardState {
  final Failure failure;
  DashboardErrorState(this.failure);
  @override List<Object?> get props => [failure.message];
}

class DashboardCubit extends Cubit<DashboardState> {
  final DashboardRepository _dashRepo;
  final AttendanceRepository _attRepo;

  DateTime _selectedDate = DateTime.now();
  String _searchQuery = '';
  String _filterStatus = '';
  String _filterDepartment = '';

  StreamSubscription<AttendanceModel>? _attendanceSub;

  DashboardCubit(this._dashRepo, this._attRepo, {AttendanceEventBus? eventBus})
      : super(DashboardInitialState()) {
    // Requirement: "After a successful API response... update attendance
    // statistics automatically." Rather than coupling this cubit to
    // whichever screen triggered the check-in/out, it listens for the
    // event and silently refreshes itself.
    _attendanceSub = eventBus?.onAttendanceRecorded.listen((_) {
      loadDashboard(silent: true);
    });
  }

  @override
  Future<void> close() {
    _attendanceSub?.cancel();
    return super.close();
  }

  Future<void> loadDashboard({bool silent = false}) async {
    if (!silent) emit(DashboardLoadingState());
    final statsResult = await _dashRepo.getDashboardStats(_selectedDate);
    final attResult = await _attRepo.getAttendanceByDate(_selectedDate);
    statsResult.fold(
      (f) => emit(DashboardErrorState(f)),
      (stats) => attResult.fold(
        (f) => emit(DashboardErrorState(f)),
        (attendance) => _emitLoaded(stats, attendance),
      ),
    );
  }

  void _emitLoaded(DashboardStatsModel stats, List<AttendanceModel> all) {
    var filtered = all;
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      filtered = filtered.where((a) => a.employeeName.toLowerCase().contains(q)).toList();
    }
    if (_filterStatus.isNotEmpty) {
      filtered = filtered.where((a) => a.status.name == _filterStatus).toList();
    }
    if (_filterDepartment.isNotEmpty) {
      filtered = filtered.where((a) => a.department == _filterDepartment).toList();
    }
    emit(DashboardLoadedState(stats: stats, todayAttendance: filtered, selectedDate: _selectedDate));
  }

  void setDate(DateTime date) { _selectedDate = date; loadDashboard(); }
  void setSearch(String q) {
    _searchQuery = q;
    if (state is DashboardLoadedState) {
      final s = state as DashboardLoadedState;
      _emitFilteredOnly(s.stats);
    }
  }
  void setFilter({String? status, String? department}) {
    if (status != null) _filterStatus = status;
    if (department != null) _filterDepartment = department;
    loadDashboard(silent: true);
  }
  void clearFilters() { _filterStatus = ''; _filterDepartment = ''; _searchQuery = ''; loadDashboard(silent: true); }

  Future<void> _emitFilteredOnly(DashboardStatsModel stats) async {
    final attResult = await _attRepo.getAttendanceByDate(_selectedDate);
    attResult.fold((_) {}, (all) => _emitLoaded(stats, all));
  }
}
