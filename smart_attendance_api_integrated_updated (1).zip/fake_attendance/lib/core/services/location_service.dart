import 'package:geolocator/geolocator.dart';

/// Simple lat/lng pair returned to the rest of the app so callers don't
/// need to depend on `package:geolocator`'s `Position` type directly.
class GeoPoint {
  final double latitude;
  final double longitude;
  const GeoPoint(this.latitude, this.longitude);
}

/// Fetches the device's current GPS location for attendance submissions.
///
/// Location is optional per the product requirements ("GPS Location if
/// available"), so this service never throws for missing permissions or a
/// disabled GPS - it simply returns `null` and lets the caller proceed
/// without coordinates.
abstract class LocationService {
  Future<GeoPoint?> getCurrentLocation();
}

class LocationServiceImpl implements LocationService {
  @override
  Future<GeoPoint?> getCurrentLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return null;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 10),
        ),
      );
      return GeoPoint(position.latitude, position.longitude);
    } catch (_) {
      // Location is best-effort; any failure just means we submit without it.
      return null;
    }
  }
}
