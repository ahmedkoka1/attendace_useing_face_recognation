import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';

/// Returns a best-effort device identifier used to tag attendance
/// submissions (helps the backend flag suspicious activity, e.g. the same
/// device checking in as multiple employees).
///
/// Device IDs are optional per the product requirements ("Device ID if
/// available"), so any failure here just returns `null`.
abstract class DeviceInfoService {
  Future<String?> getDeviceId();
}

class DeviceInfoServiceImpl implements DeviceInfoService {
  final DeviceInfoPlugin _plugin = DeviceInfoPlugin();
  String? _cachedId;

  @override
  Future<String?> getDeviceId() async {
    if (_cachedId != null) return _cachedId;
    try {
      if (Platform.isAndroid) {
        final info = await _plugin.androidInfo;
        _cachedId = info.id;
      } else if (Platform.isIOS) {
        final info = await _plugin.iosInfo;
        _cachedId = info.identifierForVendor;
      }
    } catch (_) {
      _cachedId = null;
    }
    return _cachedId;
  }
}
