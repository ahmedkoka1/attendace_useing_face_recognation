import 'package:connectivity_plus/connectivity_plus.dart';

/// Small wrapper around `connectivity_plus` so the rest of the app depends
/// on a minimal interface (easy to fake in tests) instead of the plugin
/// directly.
abstract class ConnectivityService {
  /// Best-effort check of whether the device currently has network access.
  /// Note: this only reports the OS-level connection state (Wi-Fi/mobile),
  /// not whether the backend is actually reachable.
  Future<bool> get isConnected;

  /// Emits `true`/`false` whenever connectivity changes, useful for
  /// triggering an offline-queue sync as soon as the connection returns.
  Stream<bool> get onConnectivityChanged;
}

class ConnectivityServiceImpl implements ConnectivityService {
  final Connectivity _connectivity;
  ConnectivityServiceImpl([Connectivity? connectivity])
      : _connectivity = connectivity ?? Connectivity();

  @override
  Future<bool> get isConnected async {
    final results = await _connectivity.checkConnectivity();
    return _hasConnection(results);
  }

  @override
  Stream<bool> get onConnectivityChanged =>
      _connectivity.onConnectivityChanged.map(_hasConnection);

  bool _hasConnection(List<ConnectivityResult> results) {
    return results.any((r) => r != ConnectivityResult.none);
  }
}
