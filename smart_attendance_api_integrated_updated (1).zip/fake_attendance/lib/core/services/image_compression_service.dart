import 'dart:io';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';

/// Compresses captured attendance photos before they are uploaded, to keep
/// requests fast and cheap on mobile data.
abstract class ImageCompressionService {
  /// Compresses [file] and returns the compressed copy. Falls back to the
  /// original file if compression fails for any reason (e.g. unsupported
  /// format on a given platform), so upload can still proceed.
  Future<File> compress(File file, {int quality = 70, int minWidth = 1024});
}

class ImageCompressionServiceImpl implements ImageCompressionService {
  @override
  Future<File> compress(File file, {int quality = 70, int minWidth = 1024}) async {
    try {
      final dir = await getTemporaryDirectory();
      final targetPath =
          '${dir.path}/attendance_${DateTime.now().millisecondsSinceEpoch}.jpg';

      final result = await FlutterImageCompress.compressAndGetFile(
        file.absolute.path,
        targetPath,
        quality: quality,
        minWidth: minWidth,
        format: CompressFormat.jpeg,
      );

      if (result == null) return file;
      return File(result.path);
    } catch (_) {
      // Compression is a performance optimization, not a hard requirement -
      // if it fails, upload the original image instead of blocking the flow.
      return file;
    }
  }
}
