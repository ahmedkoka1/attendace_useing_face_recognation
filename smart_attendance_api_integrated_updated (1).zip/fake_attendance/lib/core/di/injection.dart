import 'package:get_it/get_it.dart';
import 'package:smart_attendance/core/events/attendance_event_bus.dart';
import 'package:smart_attendance/core/network/api_client.dart';
import 'package:smart_attendance/core/services/connectivity_service.dart';
import 'package:smart_attendance/core/services/device_info_service.dart';
import 'package:smart_attendance/core/services/image_compression_service.dart';
import 'package:smart_attendance/core/services/location_service.dart';
import 'package:smart_attendance/modules/attendance/data/datasources/attendance_offline_queue.dart';
import 'package:smart_attendance/modules/attendance/data/datasources/attendance_remote_data_source.dart';
import 'package:smart_attendance/modules/attendance/data/repositories/attendance_repository_impl.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/auth/domain/repo/auth_repository.dart';
import 'package:smart_attendance/modules/dashboard/domain/repo/dashboard_repository.dart';
import 'package:smart_attendance/modules/employees/data/datasources/employee_remote_data_source.dart';
import 'package:smart_attendance/modules/employees/data/repositories/employee_repository_impl.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

final getIt = GetIt.instance;

Future<void> setupDi() async {
  // ---- Core services ----
  getIt.registerLazySingleton<ConnectivityService>(() => ConnectivityServiceImpl());
  getIt.registerLazySingleton<ApiClient>(() => ApiClient(getIt<ConnectivityService>()));
  getIt.registerLazySingleton<LocationService>(() => LocationServiceImpl());
  getIt.registerLazySingleton<DeviceInfoService>(() => DeviceInfoServiceImpl());
  getIt.registerLazySingleton<ImageCompressionService>(() => ImageCompressionServiceImpl());
  getIt.registerLazySingleton<AttendanceEventBus>(() => AttendanceEventBus());

  // ---- Employees data layer ----
  getIt.registerLazySingleton<EmployeeRemoteDataSource>(
    () => EmployeeRemoteDataSourceImpl(getIt<ApiClient>()),
  );

  // ---- Attendance data layer ----
  getIt.registerLazySingleton<AttendanceRemoteDataSource>(
    () => AttendanceRemoteDataSourceImpl(getIt<ApiClient>()),
  );
  getIt.registerLazySingleton<AttendanceOfflineQueue>(() => AttendanceOfflineQueue());

  // ---- Repositories ----
  getIt.registerLazySingleton<AuthRepository>(() => AuthRepositoryImpl(getIt<ApiClient>()));
  getIt.registerLazySingleton<EmployeeRepository>(
    () => EmployeeRepositoryImpl(getIt<EmployeeRemoteDataSource>()),
  );
  getIt.registerLazySingleton<AttendanceRepository>(() => AttendanceRepositoryImpl(
        remoteDataSource: getIt<AttendanceRemoteDataSource>(),
        offlineQueue: getIt<AttendanceOfflineQueue>(),
        connectivity: getIt<ConnectivityService>(),
        eventBus: getIt<AttendanceEventBus>(),
        employeeRepo: getIt<EmployeeRepository>(),
      ));
  getIt.registerLazySingleton<DashboardRepository>(
    () => DashboardRepositoryImpl(getIt<EmployeeRepository>(), getIt<AttendanceRepository>()),
  );
}
