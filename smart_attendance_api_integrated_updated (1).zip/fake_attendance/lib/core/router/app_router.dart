import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_attendance/modules/auth/presentation/cubit/auth_cubit.dart';
import 'package:smart_attendance/modules/auth/presentation/screens/login_screen.dart';
import 'package:smart_attendance/modules/dashboard/presentation/screens/dashboard_screen.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/employee_list_screen.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/employee_detail_screen.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/add_employee_screen.dart';

class AppRoutes {
  static const login = '/login';
  static const dashboard = '/dashboard';
  static const employees = '/employees';
  static const employeeDetail = '/employees/:id';
  static const addEmployee = '/employees/add';
}

GoRouter createRouter(AuthCubit authCubit) {
  return GoRouter(
    initialLocation: AppRoutes.login,
    refreshListenable: _AuthNotifier(authCubit),
    redirect: (context, state) {
      final authState = authCubit.state;
      final isLogin = state.matchedLocation == AppRoutes.login;

      if (authState is AuthAuthenticatedState && isLogin) {
        return AppRoutes.dashboard;
      }
      if (authState is AuthUnauthenticatedState && !isLogin) {
        return AppRoutes.login;
      }
      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.login,
        builder: (_, __) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.dashboard,
        builder: (_, __) => const DashboardScreen(),
      ),
      GoRoute(
        path: AppRoutes.employees,
        builder: (_, __) => const EmployeeListScreen(),
      ),
      GoRoute(
        path: AppRoutes.addEmployee,
        builder: (_, __) => const AddEmployeeScreen(),
      ),
      GoRoute(
        path: AppRoutes.employeeDetail,
        builder: (_, state) => EmployeeDetailScreen(
          employeeId: state.pathParameters['id']!,
        ),
      ),
    ],
    errorBuilder: (_, state) => Scaffold(
      body: Center(child: Text('Page not found: ${state.error}')),
    ),
  );
}

class _AuthNotifier extends ChangeNotifier {
  final AuthCubit _cubit;

  _AuthNotifier(this._cubit) {
    _cubit.stream.listen((_) => notifyListeners());
  }
}
