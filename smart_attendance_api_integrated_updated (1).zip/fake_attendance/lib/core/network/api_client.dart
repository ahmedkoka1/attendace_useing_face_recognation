import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smart_attendance/core/constants/api_constants.dart';
import 'package:smart_attendance/core/network/api_exceptions.dart';
import 'package:smart_attendance/core/services/connectivity_service.dart';

/// Thin wrapper around [Dio] that centralizes:
///  - base URL & timeout configuration
///  - auth token injection
///  - connectivity pre-checks (fail fast with a friendly error instead of
///    waiting for the OS to time out)
///  - mapping of [DioException]s into the app's typed [ApiException]s
///
/// Every repository/data source should go through this instead of creating
/// its own Dio instance, so retry/timeout/error behavior stays consistent
/// across the whole app.
class ApiClient {
  final Dio dio;
  final ConnectivityService _connectivity;

  ApiClient(this._connectivity) : dio = Dio() {
    dio.options = BaseOptions(
      baseUrl: ApiConstants.baseUrl,
      connectTimeout: ApiConstants.connectTimeout,
      sendTimeout: ApiConstants.sendTimeout,
      receiveTimeout: ApiConstants.receiveTimeout,
      headers: {
        'Accept': 'application/json',
        // Free ngrok tunnels show an HTML "Visit Site" warning page to any
        // browser-originated request (i.e. Flutter Web) unless this header
        // is present, which breaks every API call with what looks like a
        // generic connection error. Harmless to send on mobile too.
        'ngrok-skip-browser-warning': 'true',
      },
    );

    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final prefs = await SharedPreferences.getInstance();
        final token = prefs.getString(ApiConstants.authTokenPrefsKey);
        if (token != null && token.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        handler.next(options);
      },
      onError: (error, handler) async {
        // A 401 means the stored token is missing/expired/invalid - drop it
        // so the next `getCurrentAdmin()`/route redirect sends the user back
        // to the login screen instead of retrying with a dead token.
        if (error.response?.statusCode == 401) {
          await clearAuthToken();
        }
        handler.next(error);
      },
    ));
  }

  /// Persists the JWT returned by `POST /auth/login` so it can be attached
  /// to every subsequent request by the interceptor above.
  Future<void> saveAuthToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ApiConstants.authTokenPrefsKey, token);
  }

  /// Clears the stored JWT (logout, or a 401 response invalidating it).
  Future<void> clearAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(ApiConstants.authTokenPrefsKey);
  }

  Future<String?> getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(ApiConstants.authTokenPrefsKey);
  }

  /// Verifies device-level connectivity before making a call, so failures
  /// surface immediately as a friendly [NoInternetException] instead of a
  /// generic Dio connection error after the OS-level timeout.
  ///
  /// NOT called automatically anymore - `connectivity_plus`'s OS-level
  /// check produced false "no internet" negatives on some devices/emulators
  /// even with a working connection, blocking real requests. Dio's own
  /// `DioExceptionType.connectionError` (mapped to [NoInternetException] in
  /// [mapError] below) already covers the real "actually offline" case, so
  /// this pre-check is left available but unused by default. Call it
  /// explicitly only where a fast pre-flight check is worth the risk of a
  /// false negative (e.g. before a large upload).
  Future<void> ensureConnected() async {
    if (!await _connectivity.isConnected) {
      throw const NoInternetException();
    }
  }

  /// Converts any exception raised during a Dio call into one of the app's
  /// typed [ApiException]s. Call sites should wrap their `dio.xxx()` calls
  /// in `try { ... } catch (e) { throw ApiClient.mapError(e); }`.
  static ApiException mapError(Object error) {
    if (error is ApiException) return error;

    if (error is DioException) {
      switch (error.type) {
        case DioExceptionType.connectionTimeout:
        case DioExceptionType.sendTimeout:
        case DioExceptionType.receiveTimeout:
          return const RequestTimeoutException();
        case DioExceptionType.connectionError:
          return const NoInternetException();
        case DioExceptionType.badResponse:
          return _mapStatusCode(error.response?.statusCode, error);
        case DioExceptionType.cancel:
          return const UnknownApiException('Request was cancelled.');
        default:
          return UnknownApiException(error.message ?? 'Network error occurred.');
      }
    }
    return UnknownApiException(error.toString());
  }

  static ApiException _mapStatusCode(int? code, DioException error) {
    final serverMessage = _extractServerMessage(error.response?.data);
    switch (code) {
      case 400:
        return BadRequestException(serverMessage ?? 'Invalid request. Please check the submitted data.');
      case 401:
        return UnauthorizedException(serverMessage ?? 'Your session has expired. Please log in again.');
      case 403:
        return ForbiddenException(serverMessage ?? 'You do not have permission to perform this action.');
      case 404:
        return NotFoundException(serverMessage ?? 'The requested resource was not found.');
      case 500:
      case 502:
      case 503:
        return ServerException(serverMessage ?? 'Something went wrong on the server. Please try again later.');
      default:
        return UnknownApiException(serverMessage ?? 'Unexpected error (code: $code).');
    }
  }

  static String? _extractServerMessage(dynamic data) {
    try {
      if (data is Map && data['message'] is String) return data['message'] as String;
      if (data is Map && data['error'] is String) return data['error'] as String;
    } catch (_) {
      /* fall through to null */
    }
    return null;
  }
}
