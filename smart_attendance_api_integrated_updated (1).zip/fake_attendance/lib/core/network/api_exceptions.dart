import 'package:smart_attendance/core/error/failure.dart';

/// Base class for every exception the network layer can throw. Kept
/// separate from [Failure] (a UI-facing value object) so the data layer
/// stays free of any presentation concerns.
abstract class ApiException implements Exception {
  final String message;
  final FailureType type;
  const ApiException(this.message, this.type);

  Failure toFailure() => Failure(message: message, type: type);

  @override
  String toString() => message;
}

class NoInternetException extends ApiException {
  const NoInternetException([
    String message = 'No internet connection. Please check your network and try again.',
  ]) : super(message, FailureType.network);
}

class RequestTimeoutException extends ApiException {
  const RequestTimeoutException([
    String message = 'The request timed out. Please try again.',
  ]) : super(message, FailureType.timeout);
}

class BadRequestException extends ApiException {
  const BadRequestException([
    String message = 'Invalid request. Please check the submitted data.',
  ]) : super(message, FailureType.badRequest);
}

class UnauthorizedException extends ApiException {
  const UnauthorizedException([
    String message = 'Your session has expired. Please log in again.',
  ]) : super(message, FailureType.unauthorized);
}

class ForbiddenException extends ApiException {
  const ForbiddenException([
    String message = 'You do not have permission to perform this action.',
  ]) : super(message, FailureType.forbidden);
}

class NotFoundException extends ApiException {
  const NotFoundException([
    String message = 'The requested resource was not found.',
  ]) : super(message, FailureType.notFound);
}

class ServerException extends ApiException {
  const ServerException([
    String message = 'Something went wrong on the server. Please try again later.',
  ]) : super(message, FailureType.server);
}

class ImageUploadException extends ApiException {
  const ImageUploadException([
    String message = 'Failed to upload the photo. Please try again.',
  ]) : super(message, FailureType.imageUpload);
}

class UnknownApiException extends ApiException {
  const UnknownApiException([
    String message = 'An unexpected error occurred. Please try again.',
  ]) : super(message, FailureType.unknown);
}
