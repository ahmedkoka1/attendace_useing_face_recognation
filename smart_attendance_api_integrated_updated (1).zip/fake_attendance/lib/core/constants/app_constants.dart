class AppConstants {
  AppConstants._();

  static const String appName = 'Smart Attendance';
  static const String appVersion = '1.0.0';

  // Pagination
  static const int defaultPageSize = 20;
  static const int maxPageSize = 50;

  // Work Hours
  static const int workStartHour = 9;
  static const int workStartMinute = 0;
  static const int lateThresholdMinutes = 15;
  static const double requiredWorkHours = 8.0;
}

class AppColors {
  AppColors._();

  // Primary
  static const int primaryValue = 0xFF1E88E5;
  static const int primaryDarkValue = 0xFF1565C0;

  // Status
  static const int presentColor = 0xFF4CAF50;
  static const int absentColor = 0xFFF44336;
  static const int lateColor = 0xFFFF9800;
  static const int leaveColor = 0xFF9C27B0;

  // Dark Theme
  static const int darkBg = 0xFF0F1923;
  static const int darkCard = 0xFF1A2634;
  static const int darkSurface = 0xFF243447;

  // Light Theme
  static const int lightBg = 0xFFF5F7FA;
  static const int lightCard = 0xFFFFFFFF;
}
