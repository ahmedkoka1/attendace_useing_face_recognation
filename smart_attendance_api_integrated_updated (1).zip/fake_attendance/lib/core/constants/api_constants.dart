/// Central place for every REST API related constant.
///
/// Change [baseUrl] to point at your real backend. Using a single constant
/// (instead of hardcoding URLs across the app) makes it trivial to switch
/// between local, staging and production environments, e.g. via
/// `--dart-define=API_BASE_URL=https://api.example.com`.
class ApiConstants {
  ApiConstants._();

  /// Base URL of the real ASP.NET Core backend (see Swagger at
  /// https://imposing-unfitted-program.ngrok-free.dev/swagger/index.html).
  /// Override at build time with:
  /// `flutter run --dart-define=API_BASE_URL=https://your-server.com/api`
  ///
  /// NOTE: this points at a free ngrok tunnel, which is ephemeral - its URL
  /// changes every time the backend developer restarts ngrok. If requests
  /// start failing with connection errors, get the new URL from them and
  /// update this constant (or pass --dart-define=API_BASE_URL=...).
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://imposing-unfitted-program.ngrok-free.dev/api',
  );

  // ---- Auth ----
  static const String loginEndpoint = '/auth/login';
  static const String registerAdminEndpoint = '/auth/register';

  // ---- Employees ----
  static const String employeesEndpoint = '/employees';
  static String employeeByIdEndpoint(String id) => '/employees/$id';

  /// POST multipart/form-data endpoint used to upload/replace an employee's
  /// profile photo.
  ///
  /// NOTE: this exact path/field name was not visible in the Swagger
  /// screenshots captured for this integration (only the JSON
  /// Create/UpdateEmployeeRequest bodies were shown, which have no image
  /// field). `/employees/{id}/photo` is the standard REST convention for
  /// this kind of sub-resource upload and is used here so the feature is
  /// fully wired up end-to-end - confirm the real path and the multipart
  /// field name (`fieldPhoto` below) against the live Swagger doc and
  /// adjust both if the backend expects something different.
  static String employeePhotoUploadEndpoint(String id) => '/employees/$id/photo';

  // ---- Attendance ----
  /// GET endpoint that returns the full attendance history for one
  /// employee. This is the ONLY attendance-reading endpoint that exists on
  /// the backend today (see Swagger "Attendance" section) - there is no
  /// endpoint to list attendance for ALL employees on a given date.
  static String attendanceByEmployeeEndpoint(String employeeId) =>
      '/attendance/employee/$employeeId';

  /// POST multipart/form-data endpoint used to submit a check-in/check-out
  /// record together with the captured employee photo.
  ///
  /// IMPORTANT: this endpoint does NOT exist on the current backend. The
  /// Swagger doc only exposes `POST /api/face-events`, which accepts JSON
  /// (employeeId/date/time/status - no image) and is designed as a webhook
  /// for an external face-recognition device/service to push detection
  /// results, not as a mobile "submit attendance with photo" endpoint. See
  /// the integration report for details - this constant is left in place
  /// only so the offline-queue code still compiles; it is not called.
  static const String attendanceEndpoint = '/attendance';

  /// Webhook endpoint that exists on the backend (see FaceEventWebhookRequest
  /// schema) but is not wired up to any screen, since it doesn't accept an
  /// image and isn't documented as being intended for direct mobile use.
  static const String faceEventsEndpoint = '/face-events';

  // ---- Timeouts ----
  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration sendTimeout = Duration(seconds: 60); // image upload
  static const Duration receiveTimeout = Duration(seconds: 20);

  // ---- Multipart field names (must match backend contract) ----
  static const String fieldImage = 'image';
  static const String fieldEmployeeId = 'employeeId';
  static const String fieldAttendanceType = 'attendanceType';
  static const String fieldTimestamp = 'timestamp';
  static const String fieldLatitude = 'latitude';
  static const String fieldLongitude = 'longitude';
  static const String fieldDeviceId = 'deviceId';

  /// Multipart field name for the employee photo upload endpoint above -
  /// same caveat: verify against the real backend contract.
  static const String fieldPhoto = 'photo';

  // ---- Auth header ----
  /// Key under which the auth token is stored in SharedPreferences.
  static const String authTokenPrefsKey = 'auth_token';
}
