import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';

class FakeDatabase {
  FakeDatabase._();
  static final FakeDatabase instance = FakeDatabase._();

  // ===== FAKE EMPLOYEES =====
  final List<EmployeeModel> _employees = [
    EmployeeModel(id: 'e1', name: 'Ahmed Mohamed', email: 'ahmed@company.com', phone: '+201001234567', position: 'Senior Developer', department: 'Engineering', salary: 15000, address: 'Cairo, Egypt', joiningDate: DateTime(2021, 3, 15), createdAt: DateTime(2021, 3, 15)),
    EmployeeModel(id: 'e2', name: 'Sara Ali', email: 'sara@company.com', phone: '+201112345678', position: 'UI/UX Designer', department: 'Design', salary: 12000, address: 'Giza, Egypt', joiningDate: DateTime(2022, 1, 10), createdAt: DateTime(2022, 1, 10)),
    EmployeeModel(id: 'e3', name: 'Omar Hassan', email: 'omar@company.com', phone: '+201223456789', position: 'Project Manager', department: 'Management', salary: 20000, address: 'Alexandria, Egypt', joiningDate: DateTime(2020, 6, 1), createdAt: DateTime(2020, 6, 1)),
    EmployeeModel(id: 'e4', name: 'Nour Khaled', email: 'nour@company.com', phone: '+201334567890', position: 'HR Specialist', department: 'HR', salary: 10000, address: 'Cairo, Egypt', joiningDate: DateTime(2022, 8, 20), createdAt: DateTime(2022, 8, 20)),
    EmployeeModel(id: 'e5', name: 'Youssef Ibrahim', email: 'youssef@company.com', phone: '+201445678901', position: 'Backend Developer', department: 'Engineering', salary: 14000, address: 'Cairo, Egypt', joiningDate: DateTime(2021, 11, 5), createdAt: DateTime(2021, 11, 5)),
    EmployeeModel(id: 'e6', name: 'Mona Adel', email: 'mona@company.com', phone: '+201556789012', position: 'Marketing Manager', department: 'Marketing', salary: 13000, address: 'Giza, Egypt', joiningDate: DateTime(2020, 9, 15), createdAt: DateTime(2020, 9, 15)),
    EmployeeModel(id: 'e7', name: 'Karim Samir', email: 'karim@company.com', phone: '+201667890123', position: 'Mobile Developer', department: 'Engineering', salary: 13500, address: 'Cairo, Egypt', joiningDate: DateTime(2023, 2, 1), createdAt: DateTime(2023, 2, 1)),
    EmployeeModel(id: 'e8', name: 'Hana Tarek', email: 'hana@company.com', phone: '+201778901234', position: 'Graphic Designer', department: 'Design', salary: 9000, address: 'Cairo, Egypt', joiningDate: DateTime(2023, 5, 10), createdAt: DateTime(2023, 5, 10)),
    EmployeeModel(id: 'e9', name: 'Mahmoud Fathy', email: 'mahmoud@company.com', phone: '+201889012345', position: 'DevOps Engineer', department: 'Engineering', salary: 16000, address: 'Alexandria, Egypt', joiningDate: DateTime(2021, 7, 20), createdAt: DateTime(2021, 7, 20)),
    EmployeeModel(id: 'e10', name: 'Rana Mostafa', email: 'rana@company.com', phone: '+201990123456', position: 'Sales Executive', department: 'Sales', salary: 11000, address: 'Cairo, Egypt', joiningDate: DateTime(2022, 4, 3), createdAt: DateTime(2022, 4, 3)),
    EmployeeModel(id: 'e11', name: 'Amr Gamal', email: 'amr@company.com', phone: '+201101234568', position: 'QA Engineer', department: 'Engineering', salary: 12000, address: 'Giza, Egypt', joiningDate: DateTime(2022, 10, 15), createdAt: DateTime(2022, 10, 15)),
    EmployeeModel(id: 'e12', name: 'Dina Samy', email: 'dina@company.com', phone: '+201212345679', position: 'Content Writer', department: 'Marketing', salary: 8500, address: 'Cairo, Egypt', joiningDate: DateTime(2023, 1, 22), createdAt: DateTime(2023, 1, 22), status: EmployeeStatus.archived),
  ];

  List<EmployeeModel> get employees => List.unmodifiable(_employees);
  List<EmployeeModel> get activeEmployees => _employees.where((e) => e.isActive).toList();

  EmployeeModel? getEmployeeById(String id) {
    try { return _employees.firstWhere((e) => e.id == id); }
    catch (_) { return null; }
  }

  void addEmployee(EmployeeModel emp) => _employees.add(emp);

  void updateEmployee(EmployeeModel emp) {
    final idx = _employees.indexWhere((e) => e.id == emp.id);
    if (idx != -1) _employees[idx] = emp;
  }

  void deleteEmployee(String id) => _employees.removeWhere((e) => e.id == id);

  // ===== FAKE ATTENDANCE =====
  List<AttendanceModel> _generateAttendance() {
    final list = <AttendanceModel>[];
    final now = DateTime.now();
    final active = activeEmployees;
    final random = _SeededRandom(42);

    for (int dayOffset = 0; dayOffset < 30; dayOffset++) {
      final date = now.subtract(Duration(days: dayOffset));
      if (date.weekday == DateTime.friday || date.weekday == DateTime.saturday) continue;

      for (final emp in active) {
        final roll = random.nextInt(10);
        AttendanceStatus status;
        DateTime? checkIn, checkOut;
        double? hours;

        if (roll < 6) {
          status = AttendanceStatus.present;
          checkIn = DateTime(date.year, date.month, date.day, 9, random.nextInt(10));
          checkOut = DateTime(date.year, date.month, date.day, 17, random.nextInt(30));
          hours = 8.0 + (random.nextInt(4) * 0.25);
        } else if (roll < 8) {
          status = AttendanceStatus.late;
          checkIn = DateTime(date.year, date.month, date.day, 9, 20 + random.nextInt(40));
          checkOut = DateTime(date.year, date.month, date.day, 17, random.nextInt(30));
          hours = 7.0 + (random.nextInt(4) * 0.25);
        } else if (roll == 8) {
          status = AttendanceStatus.absent;
        } else {
          status = AttendanceStatus.leave;
        }

        list.add(AttendanceModel(
          id: '${emp.id}_${date.year}${date.month.toString().padLeft(2,'0')}${date.day.toString().padLeft(2,'0')}',
          employeeId: emp.id,
          employeeName: emp.name,
          department: emp.department,
          date: date,
          checkIn: checkIn,
          checkOut: checkOut,
          status: status,
          workingHours: hours,
        ));
      }
    }
    return list;
  }

  late final List<AttendanceModel> _attendance = _generateAttendance();

  List<AttendanceModel> getAttendanceByDate(DateTime date) {
    return _attendance.where((a) =>
      a.date.year == date.year &&
      a.date.month == date.month &&
      a.date.day == date.day
    ).toList();
  }

  List<AttendanceModel> getAttendanceByEmployee(String employeeId) {
    return _attendance.where((a) => a.employeeId == employeeId).toList();
  }

  /// Inserts a freshly-submitted attendance record (or replaces an existing
  /// one for the same employee/day) so the UI reflects it immediately.
  ///
  /// This demo project has no live backend to read attendance back from, so
  /// the repository calls this after a successful POST to keep the local
  /// "today's attendance" list and dashboard stats in sync. Once a real GET
  /// endpoint is available, this can be removed in favor of re-fetching
  /// from the server.
  void upsertAttendance(AttendanceModel record) {
    final idx = _attendance.indexWhere((a) =>
        a.employeeId == record.employeeId &&
        a.date.year == record.date.year &&
        a.date.month == record.date.month &&
        a.date.day == record.date.day);

    if (idx == -1) {
      _attendance.insert(0, record);
      return;
    }

    final existing = _attendance[idx];
    // Preserve the original check-in time when this record is a check-out,
    // and compute working hours once both timestamps are known.
    final checkIn = record.checkIn ?? existing.checkIn;
    final checkOut = record.checkOut ?? existing.checkOut;
    double? hours = existing.workingHours;
    if (checkIn != null && checkOut != null) {
      hours = checkOut.difference(checkIn).inMinutes / 60.0;
    }

    // Preserve the existing status (e.g. "late") rather than blindly
    // overwriting it with the incoming record's status, which is a
    // best-effort default set by the client - the existing entry (seeded or
    // previously confirmed by the backend) is the more reliable source.
    _attendance[idx] = AttendanceModel(
      id: existing.id,
      employeeId: existing.employeeId,
      employeeName: existing.employeeName,
      employeePhotoUrl: existing.employeePhotoUrl,
      department: existing.department,
      date: existing.date,
      checkIn: checkIn,
      checkOut: checkOut,
      status: existing.status,
      workingHours: hours,
      notes: existing.notes,
    );
  }

  // ===== DASHBOARD STATS =====
  DashboardStatsModel getDashboardStats(DateTime date) {
    final todayAtt = getAttendanceByDate(date);
    final total = activeEmployees.length;

    int present = 0, late = 0;
    for (final a in todayAtt) {
      if (a.status == AttendanceStatus.present) present++;
      if (a.status == AttendanceStatus.late) { present++; late++; }
    }
    final absent = total - present;
    final pct = total > 0 ? (present / total) * 100.0 : 0.0;

    // Dept stats
    final deptMap = <String, _DeptCount>{};
    for (final a in todayAtt) {
      deptMap.putIfAbsent(a.department, () => _DeptCount());
      deptMap[a.department]!.total++;
      if (a.status != AttendanceStatus.absent && a.status != AttendanceStatus.leave) {
        deptMap[a.department]!.present++;
      }
    }
    final deptStats = deptMap.entries.map((e) => DepartmentAttendanceStat(
      department: e.key, total: e.value.total, present: e.value.present,
      percentage: e.value.total > 0 ? (e.value.present / e.value.total) * 100 : 0,
    )).toList();

    // Monthly stats
    final monthlyStats = <MonthlyAttendanceStat>[];
    for (int d = 1; d <= date.day && d <= 30; d++) {
      final dayDate = DateTime(date.year, date.month, d);
      final dayAtt = getAttendanceByDate(dayDate);
      final dayPresent = dayAtt.where((a) =>
        a.status == AttendanceStatus.present || a.status == AttendanceStatus.late).length;
      monthlyStats.add(MonthlyAttendanceStat(
        day: d,
        percentage: dayAtt.isNotEmpty ? (dayPresent / dayAtt.length) * 100 : 0,
      ));
    }

    return DashboardStatsModel(
      totalEmployees: total, presentToday: present,
      absentToday: absent < 0 ? 0 : absent, lateToday: late,
      attendancePercentage: pct, monthlyStats: monthlyStats,
      departmentStats: deptStats, lastUpdated: DateTime.now(),
    );
  }
}

class _DeptCount { int total = 0; int present = 0; }

class _SeededRandom {
  int _seed;
  _SeededRandom(this._seed);
  int nextInt(int max) {
    _seed = (_seed * 1664525 + 1013904223) & 0xFFFFFFFF;
    return _seed % max;
  }
}
