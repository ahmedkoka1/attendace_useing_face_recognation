/// Broad categories of failure so the UI layer can decide how to react
/// (e.g. show a "Retry" button for [network]/[timeout], or a plain message
/// for [validation]) without string-matching on [Failure.message].
enum FailureType {
  network,
  timeout,
  unauthorized,
  forbidden,
  notFound,
  badRequest,
  server,
  imageUpload,
  permission,
  validation,
  unknown,
}

class Failure {
  final String message;
  final FailureType type;

  const Failure({required this.message, this.type = FailureType.unknown});

  factory Failure.fromException(Object e, [StackTrace? st]) {
    return Failure(message: e.toString());
  }

  @override
  String toString() => 'Failure(type: $type, message: $message)';
}
