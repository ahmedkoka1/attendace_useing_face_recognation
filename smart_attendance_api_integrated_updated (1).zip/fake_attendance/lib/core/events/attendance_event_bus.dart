import 'dart:async';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';

/// Tiny broadcast event bus that decouples the attendance feature from the
/// dashboard feature: after a successful attendance submission, the
/// repository publishes the new/updated [AttendanceModel] here, and
/// `DashboardCubit` (or any other listener) refreshes itself in response.
///
/// This avoids having the attendance UI reach into the dashboard's cubit
/// directly (which would require both to be mounted in the widget tree at
/// the same time) while still satisfying "update stats automatically".
class AttendanceEventBus {
  final _controller = StreamController<AttendanceModel>.broadcast();

  Stream<AttendanceModel> get onAttendanceRecorded => _controller.stream;

  void publish(AttendanceModel record) {
    if (!_controller.isClosed) _controller.add(record);
  }

  void dispose() => _controller.close();
}
