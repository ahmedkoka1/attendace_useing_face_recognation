import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';

abstract class AuthRepository {
  Future<Either<Failure, AdminModel>> login(String email, String password);
  Future<Either<Failure, void>> logout();
  Future<Either<Failure, void>> sendPasswordReset(String email);
  Future<Either<Failure, AdminModel?>> getCurrentAdmin();
}

// Fake admin credentials
const _fakeEmail = 'admin@company.com';
const _fakePassword = '123456';
const _fakeAdmin = AdminModel(
  id: 'admin1',
  name: 'Admin User',
  email: _fakeEmail,
  companyName: 'Smart Company',
  role: 'admin',
);

class AuthRepositoryImpl implements AuthRepository {
  bool _isLoggedIn = false;

  @override
  Future<Either<Failure, AdminModel>> login(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 800));
    if (email.trim() == _fakeEmail && password == _fakePassword) {
      _isLoggedIn = true;
      return const Right(_fakeAdmin);
    }
    return Left(Failure(message: 'Invalid email or password.\nUse: admin@company.com / 123456'));
  }

  @override
  Future<Either<Failure, void>> logout() async {
    _isLoggedIn = false;
    return const Right(null);
  }

  @override
  Future<Either<Failure, void>> sendPasswordReset(String email) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return const Right(null);
  }

  @override
  Future<Either<Failure, AdminModel?>> getCurrentAdmin() async {
    if (_isLoggedIn) return const Right(_fakeAdmin);
    return const Right(null);
  }
}
