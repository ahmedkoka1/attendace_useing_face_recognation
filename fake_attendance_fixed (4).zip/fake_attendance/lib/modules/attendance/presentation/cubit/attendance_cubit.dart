import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';

abstract class AttendanceState extends Equatable {
  @override List<Object?> get props => [];
}
class AttendanceInitialState extends AttendanceState {}
class AttendanceLoadingState extends AttendanceState {}
class AttendanceLoadedState extends AttendanceState {
  final List<AttendanceModel> records;
  AttendanceLoadedState(this.records);
  @override List<Object?> get props => [records.length];
}
class AttendanceErrorState extends AttendanceState {
  final Failure failure;
  AttendanceErrorState(this.failure);
  @override List<Object?> get props => [failure.message];
}
class AttendanceActionSuccessState extends AttendanceState {
  final String message;
  final AttendanceModel record;
  AttendanceActionSuccessState(this.message, this.record);
}
class AttendanceActionErrorState extends AttendanceState {
  final Failure failure;
  AttendanceActionErrorState(this.failure);
}

class AttendanceCubit extends Cubit<AttendanceState> {
  final AttendanceRepository _repo;
  AttendanceCubit(this._repo) : super(AttendanceInitialState());

  Future<void> loadTodayAttendance() async {
    emit(AttendanceLoadingState());
    final result = await _repo.getAttendanceByDate(DateTime.now());
    result.fold(
      (f) => emit(AttendanceErrorState(f)),
      (records) => emit(AttendanceLoadedState(records)),
    );
  }

  Future<void> checkIn({
    required String employeeId,
    required String employeeName,
    required String department,
    String? photoUrl,
  }) async {
    emit(AttendanceLoadingState());
    final result = await _repo.markAttendance(
      employeeId: employeeId,
      status: AttendanceStatus.present,
      checkIn: DateTime.now(),
    );
    result.fold(
      (f) => emit(AttendanceActionErrorState(f)),
      (record) => emit(AttendanceActionSuccessState('Check-in recorded', record)),
    );
  }

  Future<void> checkOut(String attendanceId) async {
    final currentState = state;
    AttendanceModel? existing;
    if (currentState is AttendanceLoadedState) {
      for (final r in currentState.records) {
        if (r.id == attendanceId) {
          existing = r;
          break;
        }
      }
    }

    if (existing == null) {
      emit(AttendanceActionErrorState(Failure(message: 'Attendance record not found')));
      return;
    }

    final result = await _repo.markAttendance(
      employeeId: existing.employeeId,
      status: existing.status,
      checkIn: existing.checkIn,
      checkOut: DateTime.now(),
      notes: existing.notes,
    );

    result.fold(
      (f) => emit(AttendanceActionErrorState(f)),
      (record) {
        emit(AttendanceActionSuccessState('Check-out recorded', record));
        loadTodayAttendance();
      },
    );
  }
}
