import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:smart_attendance/core/constants/app_constants.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/attendance/presentation/cubit/attendance_cubit.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

class AttendanceScreen extends StatelessWidget {
  const AttendanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AttendanceCubit(getIt<AttendanceRepository>())
        ..loadTodayAttendance(),
      child: const _AttendanceView(),
    );
  }
}

class _AttendanceView extends StatelessWidget {
  const _AttendanceView();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return BlocListener<AttendanceCubit, AttendanceState>(
      listener: (context, state) {
        if (state is AttendanceActionSuccessState) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(state.message),
            backgroundColor: const Color(AppColors.presentColor),
            behavior: SnackBarBehavior.floating,
          ));
          context.read<AttendanceCubit>().loadTodayAttendance();
        }
        if (state is AttendanceActionErrorState) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(state.failure.message),
            backgroundColor: cs.error,
            behavior: SnackBarBehavior.floating,
          ));
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Mark Attendance'),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () =>
                  context.read<AttendanceCubit>().loadTodayAttendance(),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _showMarkDialog(context),
          icon: const Icon(Icons.add),
          label: const Text('Mark Check-In'),
        ),
        body: Column(
          children: [
            // Date Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              color: cs.primary.withValues(alpha: 0.08),
              child: Row(
                children: [
                  Icon(Icons.calendar_today, color: cs.primary, size: 18),
                  const SizedBox(width: 10),
                  Text(
                    DateFormat('EEEE, MMMM dd yyyy').format(DateTime.now()),
                    style: theme.textTheme.titleMedium?.copyWith(
                        color: cs.primary, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            Expanded(
              child: BlocBuilder<AttendanceCubit, AttendanceState>(
                builder: (context, state) {
                  if (state is AttendanceLoadingState) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (state is AttendanceErrorState) {
                    return Center(child: Text(state.failure.message));
                  }
                  if (state is AttendanceLoadedState) {
                    if (state.records.isEmpty) {
                      return Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.event_busy,
                                size: 72,
                                color: cs.onSurface.withValues(alpha: 0.2)),
                            const SizedBox(height: 16),
                            Text('No attendance recorded today',
                                style: theme.textTheme.titleMedium),
                          ],
                        ),
                      );
                    }
                    return ListView.separated(
                      padding:
                          const EdgeInsets.fromLTRB(16, 12, 16, 100),
                      itemCount: state.records.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) =>
                          _AttendanceRecordCard(record: state.records[i]),
                    );
                  }
                  return const SizedBox();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMarkDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => BlocProvider.value(
        value: context.read<AttendanceCubit>(),
        child: const _MarkAttendanceDialog(),
      ),
    );
  }
}

class _MarkAttendanceDialog extends StatefulWidget {
  const _MarkAttendanceDialog();

  @override
  State<_MarkAttendanceDialog> createState() => _MarkAttendanceDialogState();
}

class _MarkAttendanceDialogState extends State<_MarkAttendanceDialog> {
  List<EmployeeModel> _employees = [];
  EmployeeModel? _selected;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadEmployees();
  }

  Future<void> _loadEmployees() async {
    setState(() => _loading = true);
    final result = await getIt<EmployeeRepository>().getEmployees();
    result.fold(
      (_) {},
      (list) => setState(() => _employees = list),
    );
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Mark Check-In'),
      content: _loading
          ? const SizedBox(
              height: 80,
              child: Center(child: CircularProgressIndicator()))
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<EmployeeModel>(
                  value: _selected,
                  hint: const Text('Select Employee'),
                  isExpanded: true,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.person_outline),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  items: _employees
                      .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.name, overflow: TextOverflow.ellipsis)))
                      .toList(),
                  onChanged: (e) => setState(() => _selected = e),
                ),
              ],
            ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel')),
        ElevatedButton(
          onPressed: _selected == null
              ? null
              : () {
                  context.read<AttendanceCubit>().checkIn(
                        employeeId: _selected!.id,
                        employeeName: _selected!.name,
                        department: _selected!.department,
                        photoUrl: _selected!.photoUrl,
                      );
                  Navigator.pop(context);
                },
          style: ElevatedButton.styleFrom(minimumSize: const Size(120, 44)),
          child: const Text('Mark Check-In'),
        ),
      ],
    );
  }
}

class _AttendanceRecordCard extends StatelessWidget {
  final AttendanceModel record;

  const _AttendanceRecordCard({required this.record});

  Color _statusColor() {
    switch (record.status) {
      case AttendanceStatus.present:
        return const Color(AppColors.presentColor);
      case AttendanceStatus.absent:
        return const Color(AppColors.absentColor);
      case AttendanceStatus.late:
        return const Color(AppColors.lateColor);
      default:
        return const Color(AppColors.leaveColor);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = _statusColor();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: color.withValues(alpha: 0.15),
              backgroundImage: record.employeePhotoUrl.isNotEmpty
                  ? null
                  : null,
              child: record.employeePhotoUrl.isEmpty
                  ? Text(
                      record.employeeName[0].toUpperCase(),
                      style: TextStyle(
                          color: color, fontWeight: FontWeight.w700))
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(record.employeeName,
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(Icons.login, size: 13,
                          color: const Color(AppColors.presentColor)),
                      const SizedBox(width: 4),
                      Text(record.formattedCheckIn,
                          style: theme.textTheme.bodySmall),
                      if (record.checkOut != null) ...[
                        const SizedBox(width: 10),
                        Icon(Icons.logout, size: 13,
                            color: const Color(AppColors.absentColor)),
                        const SizedBox(width: 4),
                        Text(record.formattedCheckOut,
                            style: theme.textTheme.bodySmall),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(record.status.name,
                      style: TextStyle(
                          color: color,
                          fontSize: 11,
                          fontWeight: FontWeight.w600)),
                ),
                if (record.checkOut == null) ...[
                  const SizedBox(height: 6),
                  GestureDetector(
                    onTap: () => context
                        .read<AttendanceCubit>()
                        .checkOut(record.id),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(AppColors.absentColor)
                            .withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text('Check Out',
                          style: TextStyle(
                              color: Color(AppColors.absentColor),
                              fontSize: 11,
                              fontWeight: FontWeight.w500)),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
