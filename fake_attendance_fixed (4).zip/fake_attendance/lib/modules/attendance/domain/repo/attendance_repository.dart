import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/fake_data/fake_database.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';

abstract class AttendanceRepository {
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByDate(DateTime date);
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByEmployee(String employeeId);
  Future<Either<Failure, AttendanceModel>> markAttendance({
    required String employeeId,
    required AttendanceStatus status,
    DateTime? checkIn,
    DateTime? checkOut,
    String? notes,
  });
  Future<Either<Failure, void>> updateAttendance(String id, AttendanceStatus status, String? notes);
}

class AttendanceRepositoryImpl implements AttendanceRepository {
  final _db = FakeDatabase.instance;

  @override
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByDate(DateTime date) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return Right(_db.getAttendanceByDate(date));
  }

  @override
  Future<Either<Failure, List<AttendanceModel>>> getAttendanceByEmployee(String employeeId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return Right(_db.getAttendanceByEmployee(employeeId));
  }

  @override
  Future<Either<Failure, AttendanceModel>> markAttendance({
    required String employeeId,
    required AttendanceStatus status,
    DateTime? checkIn,
    DateTime? checkOut,
    String? notes,
  }) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final emp = _db.getEmployeeById(employeeId);
    if (emp == null) return Left(Failure(message: 'Employee not found'));
    final now = DateTime.now();
    final record = AttendanceModel(
      id: '${employeeId}_${now.millisecondsSinceEpoch}',
      employeeId: employeeId,
      employeeName: emp.name,
      department: emp.department,
      date: now,
      checkIn: checkIn ?? now,
      checkOut: checkOut,
      status: status,
      notes: notes,
    );
    return Right(record);
  }

  @override
  Future<Either<Failure, void>> updateAttendance(String id, AttendanceStatus status, String? notes) async {
    await Future.delayed(const Duration(milliseconds: 300));
    return const Right(null);
  }
}
