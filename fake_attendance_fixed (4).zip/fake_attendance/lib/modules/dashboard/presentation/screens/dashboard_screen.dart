import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:smart_attendance/core/constants/app_constants.dart';
import 'package:smart_attendance/core/di/injection.dart';
import 'package:smart_attendance/core/theme/theme_cubit.dart';
import 'package:smart_attendance/modules/attendance/domain/models/attendance_model.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/auth/presentation/cubit/auth_cubit.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';
import 'package:smart_attendance/modules/dashboard/domain/repo/dashboard_repository.dart';
import 'package:smart_attendance/modules/dashboard/presentation/cubit/dashboard_cubit.dart';
import 'package:smart_attendance/modules/dashboard/presentation/widgets/stat_card.dart';
import 'package:smart_attendance/modules/dashboard/presentation/widgets/attendance_chart.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/employee_list_screen.dart';
import 'package:smart_attendance/modules/employees/presentation/screens/employee_detail_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => DashboardCubit(
        getIt<DashboardRepository>(),
        getIt<AttendanceRepository>(),
      )..loadDashboard(),
      child: const _DashboardView(),
    );
  }
}

class _DashboardView extends StatefulWidget {
  const _DashboardView();

  @override
  State<_DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<_DashboardView> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final isDark = context.watch<ThemeCubit>().isDark;

    return Scaffold(
      appBar: _buildAppBar(context, theme, cs, isDark),
      drawer: _buildDrawer(context, theme, cs),
      body: BlocBuilder<DashboardCubit, DashboardState>(
        builder: (context, state) {
          if (state is DashboardLoadingState) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state is DashboardErrorState) {
            return _buildError(context, state, cs);
          }
          if (state is DashboardLoadedState) {
            return _buildContent(context, theme, cs, state);
          }
          return const SizedBox();
        },
      ),
    );
  }

  AppBar _buildAppBar(BuildContext ctx, ThemeData theme, ColorScheme cs, bool isDark) {
    return AppBar(
      title: const Text('Smart Attendance'),
      actions: [
        IconButton(
          icon: Icon(isDark ? Icons.wb_sunny_outlined : Icons.nightlight_outlined),
          onPressed: () => ctx.read<ThemeCubit>().toggleTheme(),
        ),
        IconButton(
          icon: const Icon(Icons.refresh_outlined),
          onPressed: () => ctx.read<DashboardCubit>().loadDashboard(),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildDrawer(BuildContext context, ThemeData theme, ColorScheme cs) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [cs.primary, cs.secondary],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.fingerprint, color: Colors.white, size: 40),
                  const SizedBox(height: 12),
                  Text('Smart Attendance',
                      style: theme.textTheme.titleLarge
                          ?.copyWith(color: Colors.white, fontWeight: FontWeight.w700)),
                  Text('Admin Portal',
                      style: theme.textTheme.bodyMedium?.copyWith(
                          color: Colors.white.withValues(alpha: 0.8))),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard_outlined),
              title: const Text('Dashboard'),
              selected: true,
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.people_outline),
              title: const Text('Employees'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const EmployeeListScreen()));
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
              onTap: () => context.read<AuthCubit>().logout(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildError(BuildContext ctx, DashboardErrorState state, ColorScheme cs) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, size: 64, color: cs.error),
            const SizedBox(height: 16),
            Text(state.failure.message, textAlign: TextAlign.center),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => ctx.read<DashboardCubit>().loadDashboard(),
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(
      BuildContext ctx, ThemeData theme, ColorScheme cs, DashboardLoadedState state) {
    return RefreshIndicator(
      onRefresh: () => ctx.read<DashboardCubit>().loadDashboard(),
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  _buildHeader(theme, state),
                  const SizedBox(height: 20),

                  // Stats Cards
                  _buildStatsGrid(state.stats, cs),
                  const SizedBox(height: 24),

                  // Chart
                  if (state.stats.monthlyStats.isNotEmpty)
                    AttendanceChart(stats: state.stats.monthlyStats),

                  const SizedBox(height: 24),

                  // Filter Row
                  _buildFilterBar(ctx, theme, cs),
                  const SizedBox(height: 16),

                  // Search
                  _buildSearchBar(ctx, theme),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          // Attendance List
          state.todayAttendance.isEmpty
              ? SliverFillRemaining(child: _buildEmpty(theme))
              : SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (_, i) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _AttendanceCard(
                          attendance: state.todayAttendance[i],
                          onTap: () => _openEmployee(ctx, state.todayAttendance[i]),
                        ),
                      ),
                      childCount: state.todayAttendance.length,
                    ),
                  ),
                ),
        ],
      ),
    );
  }

  void _openEmployee(BuildContext ctx, AttendanceModel a) {
    Navigator.push(ctx, MaterialPageRoute(
      builder: (_) => EmployeeDetailScreen(employeeId: a.employeeId),
    ));
  }

  Widget _buildHeader(ThemeData theme, DashboardLoadedState state) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(DateFormat('EEEE, MMMM dd').format(state.selectedDate),
                  style: theme.textTheme.bodyMedium),
              const SizedBox(height: 4),
              Text("Today's Overview",
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: state.selectedDate,
              firstDate: DateTime(2020),
              lastDate: DateTime.now(),
            );
            // ignore: use_build_context_synchronously
            if (picked != null && context.mounted) {
              context.read<DashboardCubit>().setDate(picked);
            }
          },
          icon: const Icon(Icons.calendar_today, size: 16),
          label: Text(DateFormat('MMM dd').format(state.selectedDate)),
        ),
      ],
    );
  }

  Widget _buildStatsGrid(DashboardStatsModel stats, ColorScheme cs) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: [
        StatCard(
          title: 'Total Employees',
          value: stats.totalEmployees.toString(),
          icon: Icons.people,
          color: cs.primary,
        ),
        StatCard(
          title: 'Present Today',
          value: stats.presentToday.toString(),
          icon: Icons.check_circle_outline,
          color: const Color(AppColors.presentColor),
          subtitle: '${stats.attendancePercentage.toStringAsFixed(0)}%',
        ),
        StatCard(
          title: 'Absent Today',
          value: stats.absentToday.toString(),
          icon: Icons.cancel_outlined,
          color: const Color(AppColors.absentColor),
        ),
        StatCard(
          title: 'Late Today',
          value: stats.lateToday.toString(),
          icon: Icons.watch_later_outlined,
          color: const Color(AppColors.lateColor),
        ),
      ],
    );
  }

  Widget _buildFilterBar(BuildContext ctx, ThemeData theme, ColorScheme cs) {
    final filters = ['All', 'present', 'absent', 'late'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: filters.map((f) {
          final isAll = f == 'All';
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(isAll ? 'All' : f[0].toUpperCase() + f.substring(1)),
              selected: false,
              onSelected: (_) {
                ctx.read<DashboardCubit>().setFilter(status: isAll ? '' : f);
              },
              backgroundColor: theme.colorScheme.surface,
              selectedColor: cs.primary.withValues(alpha: 0.2),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSearchBar(BuildContext ctx, ThemeData theme) {
    return TextField(
      controller: _searchCtrl,
      decoration: InputDecoration(
        hintText: 'Search employees...',
        prefixIcon: const Icon(Icons.search),
        suffixIcon: _searchCtrl.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear),
                onPressed: () {
                  _searchCtrl.clear();
                  ctx.read<DashboardCubit>().setSearch('');
                },
              )
            : null,
      ),
      onChanged: (q) => ctx.read<DashboardCubit>().setSearch(q),
    );
  }

  Widget _buildEmpty(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.people_outline, size: 80,
              color: theme.colorScheme.onSurface.withValues(alpha: 0.2)),
          const SizedBox(height: 16),
          Text('No attendance records', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          Text('No data for this date', style: theme.textTheme.bodyMedium),
        ],
      ),
    );
  }
}

class _AttendanceCard extends StatelessWidget {
  final AttendanceModel attendance;
  final VoidCallback onTap;

  const _AttendanceCard({required this.attendance, required this.onTap});

  Color _statusColor() {
    switch (attendance.status) {
      case AttendanceStatus.present: return const Color(AppColors.presentColor);
      case AttendanceStatus.absent: return const Color(AppColors.absentColor);
      case AttendanceStatus.late: return const Color(AppColors.lateColor);
      default: return const Color(AppColors.leaveColor);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _statusColor();

    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              // Avatar
              CircleAvatar(
                radius: 26,
                backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.1),
                backgroundImage: attendance.employeePhotoUrl.isNotEmpty
                    ? null
                    : null,
                child: attendance.employeePhotoUrl.isEmpty
                    ? Text(
                        attendance.employeeName.isNotEmpty
                            ? attendance.employeeName[0].toUpperCase()
                            : '?',
                        style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w700,
                          fontSize: 18,
                        ),
                      )
                    : null,
              ),
              const SizedBox(width: 14),

              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(attendance.employeeName,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        )),
                    const SizedBox(height: 2),
                    Text(attendance.department,
                        style: theme.textTheme.bodySmall),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.login, size: 14,
                            color: const Color(AppColors.presentColor)),
                        const SizedBox(width: 4),
                        Text(attendance.formattedCheckIn,
                            style: theme.textTheme.bodySmall?.copyWith(
                                color: const Color(AppColors.presentColor))),
                        const SizedBox(width: 12),
                        Icon(Icons.logout, size: 14,
                            color: const Color(AppColors.absentColor)),
                        const SizedBox(width: 4),
                        Text(attendance.formattedCheckOut,
                            style: theme.textTheme.bodySmall?.copyWith(
                                color: const Color(AppColors.absentColor))),
                      ],
                    ),
                  ],
                ),
              ),

              // Status Badge
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      attendance.status.name[0].toUpperCase() +
                          attendance.status.name.substring(1),
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  if (attendance.workingHours != null) ...[
                    const SizedBox(height: 6),
                    Text(attendance.formattedWorkingHours,
                        style: theme.textTheme.bodySmall),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
