import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/fake_data/fake_database.dart';
import 'package:smart_attendance/modules/dashboard/domain/models/dashboard_stats_model.dart';

abstract class DashboardRepository {
  Future<Either<Failure, DashboardStatsModel>> getDashboardStats(DateTime date);
}

class DashboardRepositoryImpl implements DashboardRepository {
  final _db = FakeDatabase.instance;

  @override
  Future<Either<Failure, DashboardStatsModel>> getDashboardStats(DateTime date) async {
    await Future.delayed(const Duration(milliseconds: 600));
    return Right(_db.getDashboardStats(date));
  }
}
