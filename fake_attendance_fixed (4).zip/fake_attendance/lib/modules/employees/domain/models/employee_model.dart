enum EmployeeStatus { active, archived }

class EmployeeModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String position;
  final String department;
  final String? photoUrl;
  final String? address;
  final double? salary;
  final DateTime joiningDate;
  final EmployeeStatus status;
  final DateTime createdAt;
  final DateTime? updatedAt;

  const EmployeeModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.position,
    required this.department,
    this.photoUrl,
    this.address,
    this.salary,
    required this.joiningDate,
    this.status = EmployeeStatus.active,
    required this.createdAt,
    this.updatedAt,
  });

  EmployeeModel copyWith({
    String? id, String? name, String? email, String? phone,
    String? position, String? department, String? photoUrl,
    String? address, double? salary, DateTime? joiningDate,
    EmployeeStatus? status, DateTime? createdAt, DateTime? updatedAt,
  }) {
    return EmployeeModel(
      id: id ?? this.id, name: name ?? this.name, email: email ?? this.email,
      phone: phone ?? this.phone, position: position ?? this.position,
      department: department ?? this.department, photoUrl: photoUrl ?? this.photoUrl,
      address: address ?? this.address, salary: salary ?? this.salary,
      joiningDate: joiningDate ?? this.joiningDate, status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt, updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  bool get isActive => status == EmployeeStatus.active;
  bool get isArchived => status == EmployeeStatus.archived;

  String get initials {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }
}
