import 'package:fpdart/fpdart.dart';
import 'package:smart_attendance/core/error/failure.dart';
import 'package:smart_attendance/core/fake_data/fake_database.dart';
import 'package:smart_attendance/modules/employees/domain/models/employee_model.dart';
import 'package:uuid/uuid.dart';

abstract class EmployeeRepository {
  Future<Either<Failure, List<EmployeeModel>>> getEmployees({String? department, String? search, EmployeeStatus? status});
  Future<Either<Failure, EmployeeModel>> getEmployee(String id);
  Future<Either<Failure, EmployeeModel>> addEmployee(Map<String, dynamic> data);
  Future<Either<Failure, EmployeeModel>> updateEmployee(String id, Map<String, dynamic> data);
  Future<Either<Failure, void>> deleteEmployee(String id);
  Future<Either<Failure, void>> archiveEmployee(String id);
}

class EmployeeRepositoryImpl implements EmployeeRepository {
  final _db = FakeDatabase.instance;
  final _uuid = const Uuid();

  @override
  Future<Either<Failure, List<EmployeeModel>>> getEmployees({
    String? department, String? search, EmployeeStatus? status,
  }) async {
    await Future.delayed(const Duration(milliseconds: 400));
    var list = _db.employees.toList();
    if (status != null) list = list.where((e) => e.status == status).toList();
    if (department != null && department.isNotEmpty) {
      list = list.where((e) => e.department == department).toList();
    }
    if (search != null && search.isNotEmpty) {
      final q = search.toLowerCase();
      list = list.where((e) =>
        e.name.toLowerCase().contains(q) ||
        e.email.toLowerCase().contains(q) ||
        e.position.toLowerCase().contains(q)
      ).toList();
    }
    return Right(list);
  }

  @override
  Future<Either<Failure, EmployeeModel>> getEmployee(String id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final emp = _db.getEmployeeById(id);
    if (emp == null) return Left(Failure(message: 'Employee not found'));
    return Right(emp);
  }

  @override
  Future<Either<Failure, EmployeeModel>> addEmployee(Map<String, dynamic> data) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final emp = EmployeeModel(
      id: _uuid.v4(),
      name: data['name'] ?? '',
      email: data['email'] ?? '',
      phone: data['phone'] ?? '',
      position: data['position'] ?? '',
      department: data['department'] ?? '',
      address: data['address'],
      salary: data['salary'],
      joiningDate: data['joiningDate'] ?? DateTime.now(),
      createdAt: DateTime.now(),
    );
    _db.addEmployee(emp);
    return Right(emp);
  }

  @override
  Future<Either<Failure, EmployeeModel>> updateEmployee(String id, Map<String, dynamic> data) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final existing = _db.getEmployeeById(id);
    if (existing == null) return Left(Failure(message: 'Employee not found'));
    final updated = existing.copyWith(
      name: data['name'], email: data['email'], phone: data['phone'],
      position: data['position'], department: data['department'],
      address: data['address'], salary: data['salary'],
      updatedAt: DateTime.now(),
    );
    _db.updateEmployee(updated);
    return Right(updated);
  }

  @override
  Future<Either<Failure, void>> deleteEmployee(String id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _db.deleteEmployee(id);
    return const Right(null);
  }

  @override
  Future<Either<Failure, void>> archiveEmployee(String id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final emp = _db.getEmployeeById(id);
    if (emp == null) return Left(Failure(message: 'Employee not found'));
    _db.updateEmployee(emp.copyWith(status: EmployeeStatus.archived));
    return const Right(null);
  }
}
