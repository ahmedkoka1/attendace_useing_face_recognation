import 'package:get_it/get_it.dart';
import 'package:smart_attendance/modules/attendance/domain/repo/attendance_repository.dart';
import 'package:smart_attendance/modules/auth/domain/repo/auth_repository.dart';
import 'package:smart_attendance/modules/dashboard/domain/repo/dashboard_repository.dart';
import 'package:smart_attendance/modules/employees/domain/repo/employee_repository.dart';

final getIt = GetIt.instance;

Future<void> setupDi() async {
  getIt.registerLazySingleton<AuthRepository>(() => AuthRepositoryImpl());
  getIt.registerLazySingleton<EmployeeRepository>(() => EmployeeRepositoryImpl());
  getIt.registerLazySingleton<AttendanceRepository>(() => AttendanceRepositoryImpl());
  getIt.registerLazySingleton<DashboardRepository>(() => DashboardRepositoryImpl());
}
