class Failure {
  final String message;
  const Failure({required this.message});

  factory Failure.fromException(Object e, [StackTrace? st]) {
    return Failure(message: e.toString());
  }
}
